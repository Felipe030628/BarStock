package Pruebas.Eliminar;

import Controlador.EstadoPedidoDAO;

public class PruebaEstadoPedidoEliminar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        EstadoPedidoDAO dao = new EstadoPedidoDAO();

        // 2. Definir el ID que quieres borrar (asegúrate que exista en la DB)
        int idParaEliminar = 3; 

        System.out.println("Iniciando eliminación del ID: " + idParaEliminar);

        // 3. Ejecutar el método eliminar
        dao.eliminar(idParaEliminar);

        System.out.println("Prueba finalizada. Revisa tu base de datos para confirmar.");
    }
}
package Pruebas.Eliminar;

import Controlador.MesaDAO;

public class PruebaMesaEliminar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        MesaDAO dao = new MesaDAO();

        // 2. Definir el ID de la mesa que quieres borrar
        int idAEliminar = 1; 

        System.out.println("Intentando eliminar la mesa con ID: " + idAEliminar);

        // 3. Llamar al método eliminar
        dao.eliminar(idAEliminar);
        
        // Mensaje de confirmación en la consola
        System.out.println("Proceso finalizado. Verifica tu base de datos.");
    }
}
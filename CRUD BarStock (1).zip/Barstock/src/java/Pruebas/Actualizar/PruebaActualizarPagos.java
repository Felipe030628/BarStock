package Pruebas.Actualizar;

import Controlador.PagosDAO;
import java.util.Scanner;
import modelo.Pagos;

public class PruebaActualizarPagos {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PagosDAO dao = new PagosDAO();
        Pagos p = new Pagos();

        System.out.println("=== ACTUALIZAR PAGO ===");

        System.out.print("Ingrese el ID del Pago a actualizar: ");
        p.idPagos = sc.nextInt();

        System.out.print("Nuevo monto: ");
        p.monto = sc.nextDouble();

        System.out.print("ID Pedido Cabecera: ");
        p.pedido_Cabecera_idPedido = sc.nextInt();

        System.out.print("ID Estado Pago: ");
        p.estados_Pag_idEstados_Pag = sc.nextInt();

        System.out.print("ID Metodo Pago: ");
        p.metodos_Pago_idMetodos_Pago = sc.nextInt();

        dao.actualizar(p);

        System.out.println("Pago actualizado correctamente");

        sc.close();
    }
}
package Pruebas.Actualizar;

import Controlador.SeguimientoPedidoDAO;
import java.util.Scanner;
import modelo.SeguimientoPedido;

public class PruebaActualizarSeguimientoPedido {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        SeguimientoPedidoDAO dao = new SeguimientoPedidoDAO();
        SeguimientoPedido s = new SeguimientoPedido();

        System.out.println("=== ACTUALIZAR SEGUIMIENTO PEDIDO ===");

        System.out.print("Ingrese el ID del Seguimiento a actualizar: ");
        s.idSeguimientoPedido = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        System.out.print("Nueva descripción del seguimiento: ");
        s.seguimientoPedidoCol = sc.nextLine();

        System.out.print("Nuevo ID Estado Pedido: ");
        s.estadoPedidoId = sc.nextInt();

        System.out.print("Nuevo ID Pedido: ");
        s.pedidoId = sc.nextInt();

        dao.actualizar(s);

        System.out.println("Seguimiento actualizado correctamente");

        sc.close();
    }
}
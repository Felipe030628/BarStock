package Pruebas.Actualizar;

import Controlador.MovimientoStockDAO;
import java.util.Scanner;
import java.util.Date;
import modelo.MovimientosStock;

public class PruebaActualizarMovimientoStock {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MovimientoStockDAO dao = new MovimientoStockDAO();
        MovimientosStock m = new MovimientosStock();

        System.out.println("=== ACTUALIZAR MOVIMIENTO STOCK ===");

        System.out.print("Ingrese el ID del Movimiento a actualizar: ");
        m.idMovimientos_stock = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        // Fecha automática (fecha actual)
        m.fecha_movimiento = new Date();

        System.out.print("Nueva cantidad: ");
        m.cantidad = sc.nextInt();
        sc.nextLine();

        System.out.print("Nuevo motivo: ");
        m.motivo = sc.nextLine();

        System.out.print("ID del Producto: ");
        m.productos_idProductos = sc.nextInt();

        dao.actualizar(m);

        sc.close();
    }
}
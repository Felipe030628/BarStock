package Pruebas.Actualizar;

import Controlador.UsuariosDAO;
import java.util.Scanner;
import modelo.Usuarios;

public class PruebaActualizarUsuarios {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        UsuariosDAO dao = new UsuariosDAO();
        Usuarios u = new Usuarios();

        System.out.println("=== ACTUALIZAR USUARIO ===");

        System.out.print("Ingrese el ID del Usuario a actualizar: ");
        u.idUsuarios = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        System.out.print("Nuevo nombre: ");
        u.nombre = sc.nextLine();

        System.out.print("Nuevo email: ");
        u.email = sc.nextLine();

        System.out.print("Nuevo teléfono: ");
        u.tel = sc.nextLine();

        dao.actualizar(u);

        System.out.println("Usuario actualizado correctamente");

        sc.close();
    }
}
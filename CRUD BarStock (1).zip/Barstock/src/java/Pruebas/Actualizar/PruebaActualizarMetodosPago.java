package Pruebas.Actualizar;

import Controlador.MetodosPagoDAO;
import java.util.Scanner;
import modelo.MetodosPago;

public class PruebaActualizarMetodosPago {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MetodosPagoDAO dao = new MetodosPagoDAO();
        MetodosPago m = new MetodosPago();

        System.out.println("=== ACTUALIZAR METODO DE PAGO ===");

        System.out.print("Ingrese el ID del Metodo de Pago a actualizar: ");
        m.idMetodos_Pago = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        System.out.print("Nueva descripción del Metodo de Pago: ");
        m.descripcion_Metodo = sc.nextLine();

        dao.actualizar(m);

        sc.close();
    }
}
package Pruebas.Actualizar;

import Controlador.EstadoPedidoDAO;
import java.util.Scanner;
import modelo.EstadoPedido;

public class PruebaActualizarEstadoPedido {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        EstadoPedidoDAO dao = new EstadoPedidoDAO();
        EstadoPedido e = new EstadoPedido();

        System.out.println("=== ACTUALIZAR ESTADO PEDIDO ===");

        System.out.print("Ingrese el ID del Estado a actualizar: ");
        e.idEstado_Pedido = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        System.out.print("Nuevo nombre del Estado: ");
        e.estado_pedidoCol = sc.nextLine();

        dao.actualizar(e);

        sc.close();
    }
}
package Pruebas.Actualizar;

import Controlador.MesaDAO;
import java.util.Scanner;
import modelo.Mesa;

public class PruebaActualizarMesa {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MesaDAO dao = new MesaDAO();
        Mesa m = new Mesa();

        System.out.println("=== ACTUALIZAR MESA ===");

        System.out.print("Ingrese el ID de la Mesa a actualizar: ");
        m.idMesa = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        System.out.print("Nuevo código de la Mesa: ");
        m.cod_mesa = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        System.out.print("Nuevo número de la Mesa: ");
        m.num_mesa = sc.nextLine();

        dao.actualizar(m);

        sc.close();
    }
}
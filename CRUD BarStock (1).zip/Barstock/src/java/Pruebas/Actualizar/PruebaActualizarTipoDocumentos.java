package Pruebas.Actualizar;

import Controlador.TipoDocumentosDAO;
import java.util.Scanner;
import modelo.TiposDocumentos;

public class PruebaActualizarTipoDocumentos {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        TipoDocumentosDAO dao = new TipoDocumentosDAO();
        TiposDocumentos t = new TiposDocumentos();

        System.out.println("=== ACTUALIZAR TIPO DOCUMENTO ===");

        System.out.print("Ingrese el ID del Tipo Documento a actualizar: ");
        t.idTipos_documentos = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        System.out.print("Nueva descripción del Documento: ");
        t.descripcion_Doc = sc.nextLine();

        System.out.print("Nuevo consecutivo: ");
        t.consecutivo = sc.nextInt();

        System.out.print("Nuevo ID Usuario: ");
        t.usuarios_idUsuarios = sc.nextInt();

        dao.actualizar(t);

        System.out.println("Tipo de documento actualizado correctamente");

        sc.close();
    }
}
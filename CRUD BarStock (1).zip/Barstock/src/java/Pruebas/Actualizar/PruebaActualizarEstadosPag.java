package Pruebas.Actualizar;

import Controlador.EstadosPagDAO;
import java.util.Scanner;
import modelo.EstadosPag;

public class PruebaActualizarEstadosPag {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        EstadosPagDAO dao = new EstadosPagDAO();
        EstadosPag e = new EstadosPag();

        System.out.println("=== ACTUALIZAR ESTADO DE PAGO ===");

        System.out.print("Ingrese el ID del Estado de Pago a actualizar: ");
        e.idEstados_Pag = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        System.out.print("Nueva descripción del Estado de Pago: ");
        e.descripcion_EstadoPago = sc.nextLine();

        dao.actualizar(e);

        sc.close();
    }
}
package Pruebas.Actualizar;

import Controlador.PedidoCabeceraDAO;
import java.util.Scanner;
import java.sql.Timestamp;
import modelo.PedidoCabecera;

public class PruebaActualizarPedidoCabecera {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PedidoCabeceraDAO dao = new PedidoCabeceraDAO();
        PedidoCabecera p = new PedidoCabecera();

        System.out.println("=== ACTUALIZAR PEDIDO CABECERA ===");

        System.out.print("Ingrese el ID del Pedido a actualizar: ");
        p.idPedido = sc.nextInt();

        // Fecha y hora actual
        p.fecha_hora = new Timestamp(System.currentTimeMillis());

        System.out.print("Nuevo ID Usuario: ");
        p.usuarios_idUsuarios = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        System.out.print("Nuevo ID Mesa: ");
        p.mesa_idMesa = sc.nextLine();

        dao.actualizar(p);

        System.out.println("Pedido actualizado correctamente");

        sc.close();
    }
}
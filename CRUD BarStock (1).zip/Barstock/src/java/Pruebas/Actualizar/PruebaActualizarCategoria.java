package Pruebas.Actualizar;

import Controlador.CategoriaDAO;
import java.util.Scanner;
import modelo.Categorias;

public class PruebaActualizarCategoria {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        CategoriaDAO dao = new CategoriaDAO();
        Categorias c = new Categorias();

        System.out.println("=== ACTUALIZAR CATEGORIA ===");

        System.out.print("Ingrese el ID de la categoria a actualizar: ");
        c.idCategorias = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        System.out.print("Nuevo nombre de la categoria: ");
        c.nom_categoria = sc.nextLine();

        System.out.print("Nueva descripcion: ");
        c.descripcion = sc.nextLine();

        dao.actualizar(c);

        sc.close();
    }
}
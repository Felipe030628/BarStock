package Pruebas.Actualizar;

import Controlador.ProductosDAO;
import java.util.Scanner;
import java.util.Date;
import modelo.Productos;

public class PruebaActualizarProductos {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ProductosDAO dao = new ProductosDAO();
        Productos p = new Productos();

        System.out.println("=== ACTUALIZAR PRODUCTO ===");

        System.out.print("Ingrese el ID del Producto a actualizar: ");
        p.idProductos = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        System.out.print("Nuevo numero del producto: ");
        p.num_productos = sc.nextLine();

        System.out.print("Nueva descripcion: ");
        p.descripcion = sc.nextLine();

        System.out.print("Nuevo precio: ");
        p.precio = sc.nextDouble();

        System.out.print("Nuevo stock: ");
        p.stock = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        // Fecha actual automática
        p.fecha_vencimiento = new Date();

        System.out.print("Nuevo ID Categoria: ");
        p.categorias_idCategorias = sc.nextInt();

        dao.actualizar(p);

        System.out.println("Producto actualizado correctamente");

        sc.close();
    }
}
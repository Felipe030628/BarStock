package pruebas.listar;

import Controlador.MetodosPagoDAO;
import modelo.MetodosPago;
import java.util.List;

public class MetodoPagoListar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        MetodosPagoDAO dao = new MetodosPagoDAO();

        // 2. Obtener la lista desde la base de datos
        List<MetodosPago> lista = dao.listar();

        // 3. Imprimir los resultados
        System.out.println("=== MÉTODOS DE PAGO DISPONIBLES ===");
        
        if (lista.isEmpty()) {
            System.out.println("No hay métodos de pago registrados.");
        } else {
            for (MetodosPago m : lista) {
                System.out.println("ID: " + m.idMetodos_Pago + " | Descripción: " + m.descripcion_Metodo);
            }
            System.out.println("===================================");
            System.out.println("Total encontrados: " + lista.size());
        }
    }
}
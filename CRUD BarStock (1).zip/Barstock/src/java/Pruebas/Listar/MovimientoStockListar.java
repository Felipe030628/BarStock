package pruebas.listar;

import Controlador.MovimientoStockDAO;
import modelo.MovimientosStock;
import java.util.List;

public class MovimientoStockListar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        MovimientoStockDAO dao = new MovimientoStockDAO();

        // 2. Obtener el historial de movimientos
        List<MovimientosStock> historial = dao.listar();

        // 3. Imprimir los resultados
        System.out.println("=== HISTORIAL DE MOVIMIENTOS DE STOCK ===");
        
        if (historial.isEmpty()) {
            System.out.println("No se registran movimientos en el sistema.");
        } else {
            for (MovimientosStock m : historial) {
                System.out.println("ID Mov: " + m.idMovimientos_stock + 
                                   " | Fecha: " + m.fecha_movimiento + 
                                   " | Cant: " + m.cantidad + 
                                   " | Motivo: " + m.motivo + 
                                   " | ID Prod: " + m.productos_idProductos);
            }
            System.out.println("=========================================");
            System.out.println("Total de movimientos: " + historial.size());
        }
    }
}
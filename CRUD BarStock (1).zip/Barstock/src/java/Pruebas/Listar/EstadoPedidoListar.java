package pruebas.listar;

import Controlador.EstadoPedidoDAO;
import modelo.EstadoPedido;
import java.util.List;

public class EstadoPedidoListar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        EstadoPedidoDAO dao = new EstadoPedidoDAO();

        // 2. Obtener la lista de todos los estados
        List<EstadoPedido> lista = dao.listar();

        // 3. Imprimir los resultados de forma clara
        System.out.println("=== LISTADO DE ESTADOS DE PEDIDO ===");
        
        if (lista.isEmpty()) {
            System.out.println("No hay estados registrados en la base de datos.");
        } else {
            for (EstadoPedido ep : lista) {
                System.out.println("ID: " + ep.idEstado_Pedido + " | Nombre: " + ep.estado_pedidoCol);
            }
            System.out.println("====================================");
            System.out.println("Total de registros: " + lista.size());
        }
    }
}
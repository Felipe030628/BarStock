package pruebas.listar;

import Controlador.PedidoCabeceraDAO;
import modelo.PedidoCabecera;
import java.util.List;

public class PedidoCabeceraListar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        PedidoCabeceraDAO dao = new PedidoCabeceraDAO();

        // 2. Obtener la lista de cabeceras de pedidos
        List<PedidoCabecera> lista = dao.listar();

        // 3. Imprimir los resultados
        System.out.println("=== LISTADO DE CABECERAS DE PEDIDOS ===");
        
        if (lista.isEmpty()) {
            System.out.println("No hay pedidos registrados en el sistema.");
        } else {
            for (PedidoCabecera p : lista) {
                System.out.println("ID Pedido: " + p.idPedido + 
                                   " | Fecha/Hora: " + p.fecha_hora + 
                                   " | ID Usuario: " + p.usuarios_idUsuarios + 
                                   " | ID Mesa: " + p.mesa_idMesa);
            }
            System.out.println("=======================================");
            System.out.println("Total de pedidos: " + lista.size());
        }
    }
}
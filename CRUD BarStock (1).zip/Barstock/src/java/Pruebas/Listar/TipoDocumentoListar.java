package pruebas.listar;

import Controlador.TipoDocumentosDAO;
import modelo.TiposDocumentos;
import java.util.List;

public class TipoDocumentoListar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        TipoDocumentosDAO dao = new TipoDocumentosDAO();

        // 2. Obtener la lista de tipos de documentos
        List<TiposDocumentos> lista = dao.listar();

        // 3. Imprimir los resultados
        System.out.println("=== LISTADO DE TIPOS DE DOCUMENTOS ===");
        
        if (lista.isEmpty()) {
            System.out.println("No hay tipos de documentos registrados.");
        } else {
            for (TiposDocumentos t : lista) {
                System.out.println("ID: " + t.idTipos_documentos + 
                                   " | Descripción: " + t.descripcion_Doc + 
                                   " | Consecutivo: " + t.consecutivo + 
                                   " | ID Usuario: " + t.usuarios_idUsuarios);
            }
            System.out.println("======================================");
            System.out.println("Total de registros: " + lista.size());
        }
    }
}
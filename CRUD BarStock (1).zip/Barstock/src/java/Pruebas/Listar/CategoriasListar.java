package pruebas.listar;

import Controlador.CategoriaDAO;
import modelo.Categorias;
import java.util.List;

public class CategoriasListar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO para acceder a los datos
        CategoriaDAO dao = new CategoriaDAO();

        // 2. Llamar al método listar y guardar el resultado
        List<Categorias> todasLasCategorias = dao.listar();

        // 3. Imprimir los resultados de forma sencilla
        System.out.println("=== REPORTE DE CATEGORÍAS EN SISTEMA ===");
        
        if (todasLasCategorias.isEmpty()) {
            System.out.println("La tabla de categorías está vacía actualmente.");
        } else {
            for (Categorias c : todasLasCategorias) {
                System.out.println("ID: " + c.idCategorias + " | Nombre: " + c.nom_categoria + " | Desc: " + c.descripcion);
            }
            System.out.println("========================================");
            System.out.println("Total encontradas: " + todasLasCategorias.size());
        }
    }
}
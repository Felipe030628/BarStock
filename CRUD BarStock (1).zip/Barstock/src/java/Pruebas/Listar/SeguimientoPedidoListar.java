package pruebas.listar;

import Controlador.SeguimientoPedidoDAO;
import modelo.SeguimientoPedido;
import java.util.List;

public class SeguimientoPedidoListar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        SeguimientoPedidoDAO dao = new SeguimientoPedidoDAO();

        // 2. Obtener la lista de seguimientos
        List<SeguimientoPedido> lista = dao.listar();

        // 3. Imprimir los resultados de forma clara
        System.out.println("=== LISTADO DE SEGUIMIENTO DE PEDIDOS ===");
        
        if (lista.isEmpty()) {
            System.out.println("No hay registros de seguimiento en la base de datos.");
        } else {
            for (SeguimientoPedido s : lista) {
                System.out.println("ID Seguimiento: " + s.idSeguimientoPedido + 
                                   " | Nota/Col: " + s.seguimientoPedidoCol + 
                                   " | ID Estado: " + s.estadoPedidoId + 
                                   " | ID Pedido: " + s.pedidoId);
            }
            System.out.println("==========================================");
            System.out.println("Total de registros: " + lista.size());
        }
    }
}
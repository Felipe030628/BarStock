package pruebas.listar;

import Controlador.ProductosDAO;
import modelo.Productos;
import java.util.List;

public class ProductosListar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        ProductosDAO dao = new ProductosDAO();

        // 2. Obtener la lista de productos
        List<Productos> lista = dao.listar();

        // 3. Imprimir los resultados
        System.out.println("=== INVENTARIO DE PRODUCTOS ===");
        
        if (lista.isEmpty()) {
            System.out.println("No hay productos registrados en la base de datos.");
        } else {
            for (Productos p : lista) {
                System.out.println("ID: " + p.idProductos + 
                                   " | Código: " + p.num_productos + 
                                   " | Nombre: " + p.descripcion + 
                                   " | Precio: $" + p.precio + 
                                   " | Stock: " + p.stock + 
                                   " | Vence: " + p.fecha_vencimiento + 
                                   " | Cat ID: " + p.categorias_idCategorias);
            }
            System.out.println("===============================");
            System.out.println("Total de productos: " + lista.size());
        }
    }
}
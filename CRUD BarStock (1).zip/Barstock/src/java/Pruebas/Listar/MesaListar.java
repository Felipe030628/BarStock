package pruebas.listar;

import Controlador.MesaDAO;
import modelo.Mesa;
import java.util.List;

public class MesaListar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        MesaDAO dao = new MesaDAO();

        // 2. Obtener la lista de todas las mesas
        List<Mesa> lista = dao.listar();

        // 3. Recorrer la lista y mostrar los datos
        System.out.println("=== LISTADO DE MESAS REGISTRADAS ===");
        
        if (lista.isEmpty()) {
            System.out.println("No hay mesas en la base de datos.");
        } else {
            for (Mesa m : lista) {
                System.out.println("ID: " + m.idMesa + 
                                   " | Código: " + m.cod_mesa + 
                                   " | Número: " + m.num_mesa);
            }
            System.out.println("====================================");
            System.out.println("Total de mesas: " + lista.size());
        }
    }
}
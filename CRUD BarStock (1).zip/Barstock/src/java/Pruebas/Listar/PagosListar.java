package pruebas.listar;

import Controlador.PagosDAO;
import modelo.Pagos;
import java.util.List;

public class PagosListar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        PagosDAO dao = new PagosDAO();

        // 2. Obtener la lista de pagos registrados
        List<Pagos> listaPagos = dao.listar();

        // 3. Mostrar los resultados
        System.out.println("=== LISTADO DE PAGOS REGISTRADOS ===");
        
        if (listaPagos.isEmpty()) {
            System.out.println("No se encontraron pagos en la base de datos.");
        } else {
            for (Pagos p : listaPagos) {
                System.out.println("ID Pago: " + p.idPagos + 
                                   " | Monto: $" + p.monto + 
                                   " | ID Pedido: " + p.pedido_Cabecera_idPedido + 
                                   " | ID Estado: " + p.estados_Pag_idEstados_Pag + 
                                   " | ID Método: " + p.metodos_Pago_idMetodos_Pago);
            }
            System.out.println("====================================");
            System.out.println("Total de registros: " + listaPagos.size());
        }
    }
}
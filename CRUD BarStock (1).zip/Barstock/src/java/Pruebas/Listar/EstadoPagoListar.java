package pruebas.listar;

import Controlador.EstadosPagDAO;
import modelo.EstadosPag;
import java.util.List;

public class EstadoPagoListar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        EstadosPagDAO dao = new EstadosPagDAO();

        // 2. Obtener la lista de estados de pago
        List<EstadosPag> lista = dao.listar();

        // 3. Imprimir los resultados
        System.out.println("=== LISTADO DE ESTADOS DE PAGO ===");
        
        if (lista.isEmpty()) {
            System.out.println("No se encontraron estados de pago en la base de datos.");
        } else {
            for (EstadosPag ep : lista) {
                System.out.println("ID: " + ep.idEstados_Pag + " | Descripción: " + ep.descripcion_EstadoPago);
            }
            System.out.println("==================================");
            System.out.println("Total de registros: " + lista.size());
        }
    }
}
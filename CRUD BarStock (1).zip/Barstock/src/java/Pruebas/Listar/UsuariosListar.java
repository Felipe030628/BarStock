package pruebas.listar;

import Controlador.UsuariosDAO;
import modelo.Usuarios;
import java.util.List;

public class UsuariosListar {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        UsuariosDAO dao = new UsuariosDAO();

        // 2. Obtener la lista de usuarios
        List<Usuarios> lista = dao.listar();

        // 3. Imprimir los resultados de forma organizada
        System.out.println("=== LISTADO DE USUARIOS DEL SISTEMA ===");
        
        if (lista.isEmpty()) {
            System.out.println("No hay usuarios registrados en la base de datos.");
        } else {
            for (Usuarios u : lista) {
                System.out.println("ID: " + u.idUsuarios + 
                                   " | Nombre: " + u.nombre + 
                                   " | Email: " + u.email + 
                                   " | Tel: " + u.tel);
            }
            System.out.println("=======================================");
            System.out.println("Total de usuarios: " + lista.size());
        }
    }
}
package Pruebas.Consultar;

import Controlador.PedidoCabeceraDAO;
import java.util.Scanner;
import modelo.PedidoCabecera;

public class PruebaConsultarPedidoCabecera {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PedidoCabeceraDAO dao = new PedidoCabeceraDAO();

        System.out.println("=== CONSULTAR PEDIDO CABECERA ===");
        System.out.print("Ingrese el ID del Pedido: ");
        int id = sc.nextInt();

        PedidoCabecera p = dao.consultar(id);

        if (p.idPedido != 0) {
            System.out.println("\n--- DATOS ENCONTRADOS ---");
            System.out.println("ID Pedido: " + p.idPedido);
            System.out.println("Fecha y Hora: " + p.fecha_hora);
            System.out.println("ID Usuario: " + p.usuarios_idUsuarios);
            System.out.println("ID Mesa: " + p.mesa_idMesa);
        } else {
            System.out.println("No se encontró el pedido.");
        }

        sc.close();
    }
}
package Pruebas.Consultar;

import Controlador.CategoriaDAO;
import java.util.Scanner;
import modelo.Categorias;

public class PruebaConsultarCategoria {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        CategoriaDAO dao = new CategoriaDAO();

        System.out.println("=== CONSULTAR CATEGORIA ===");
        System.out.print("Ingrese el ID de la categoria: ");
        int id = sc.nextInt();

        Categorias c = dao.consultar(id);

        if (c.idCategorias != 0) {
            System.out.println("\n--- DATOS ENCONTRADOS ---");
            System.out.println("ID: " + c.idCategorias);
            System.out.println("Nombre: " + c.nom_categoria);
            System.out.println("Descripcion: " + c.descripcion);
        } else {
            System.out.println("No se encontró la categoria.");
        }

        sc.close();
    }
}

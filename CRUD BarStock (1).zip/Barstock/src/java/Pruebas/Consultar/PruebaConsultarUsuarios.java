package Pruebas.Consultar;

import Controlador.UsuariosDAO;
import java.util.Scanner;
import modelo.Usuarios;

public class PruebaConsultarUsuarios {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        UsuariosDAO dao = new UsuariosDAO();

        System.out.println("=== CONSULTAR USUARIO ===");
        System.out.print("Ingrese el ID del Usuario: ");
        int id = sc.nextInt();

        Usuarios u = dao.consultar(id);

        if (u.idUsuarios != 0) {
            System.out.println("\n--- DATOS ENCONTRADOS ---");
            System.out.println("ID: " + u.idUsuarios);
            System.out.println("Nombre: " + u.nombre);
            System.out.println("Email: " + u.email);
            System.out.println("Teléfono: " + u.tel);
        } else {
            System.out.println("No se encontró el usuario.");
        }

        sc.close();
    }
}
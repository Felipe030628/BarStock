package Pruebas.Consultar;

import Controlador.PagosDAO;
import java.util.Scanner;
import modelo.Pagos;

public class PruebaConsultarPagos {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PagosDAO dao = new PagosDAO();

        System.out.println("=== CONSULTAR PAGO ===");
        System.out.print("Ingrese el ID del Pago: ");
        int id = sc.nextInt();

        Pagos p = dao.consultar(id);

        if (p.idPagos != 0) {
            System.out.println("\n--- DATOS ENCONTRADOS ---");
            System.out.println("ID: " + p.idPagos);
            System.out.println("Monto: " + p.monto);
            System.out.println("ID Pedido: " + p.pedido_Cabecera_idPedido);
            System.out.println("ID Estado Pago: " + p.estados_Pag_idEstados_Pag);
            System.out.println("ID Metodo Pago: " + p.metodos_Pago_idMetodos_Pago);
        } else {
            System.out.println("No se encontró el pago.");
        }

        sc.close();
    }
}
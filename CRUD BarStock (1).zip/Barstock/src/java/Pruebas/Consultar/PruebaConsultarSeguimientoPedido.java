package Pruebas.Consultar;

import Controlador.SeguimientoPedidoDAO;
import java.util.Scanner;
import modelo.SeguimientoPedido;

public class PruebaConsultarSeguimientoPedido {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        SeguimientoPedidoDAO dao = new SeguimientoPedidoDAO();

        System.out.println("=== CONSULTAR SEGUIMIENTO PEDIDO ===");
        System.out.print("Ingrese el ID del Seguimiento: ");
        int id = sc.nextInt();

        SeguimientoPedido s = dao.consultar(id);

        if (s.idSeguimientoPedido != 0) {
            System.out.println("\n--- DATOS ENCONTRADOS ---");
            System.out.println("ID: " + s.idSeguimientoPedido);
            System.out.println("Descripción Seguimiento: " + s.seguimientoPedidoCol);
            System.out.println("ID Estado Pedido: " + s.estadoPedidoId);
            System.out.println("ID Pedido: " + s.pedidoId);
        } else {
            System.out.println("No se encontró el seguimiento del pedido.");
        }

        sc.close();
    }
}
package Pruebas.Consultar;

import Controlador.EstadoPedidoDAO;
import java.util.Scanner;
import modelo.EstadoPedido;

public class PruebaConsultarEstadoPedido {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        EstadoPedidoDAO dao = new EstadoPedidoDAO();

        System.out.println("=== CONSULTAR ESTADO PEDIDO ===");
        System.out.print("Ingrese el ID del Estado del Pedido: ");
        int id = sc.nextInt();

        EstadoPedido e = dao.consultar(id);

        if (e.idEstado_Pedido != 0) {
            System.out.println("\n--- DATOS ENCONTRADOS ---");
            System.out.println("ID: " + e.idEstado_Pedido);
            System.out.println("Estado: " + e.estado_pedidoCol);
        } else {
            System.out.println("No se encontró el estado del pedido.");
        }

        sc.close();
    }
}

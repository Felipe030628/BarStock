package Pruebas.Consultar;

import Controlador.MovimientoStockDAO;
import java.util.Scanner;
import modelo.MovimientosStock;

public class PruebaConsultarMovimientoStock {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MovimientoStockDAO dao = new MovimientoStockDAO();

        System.out.println("=== CONSULTAR MOVIMIENTO DE STOCK ===");
        System.out.print("Ingrese el ID del Movimiento: ");
        int id = sc.nextInt();

        MovimientosStock m = dao.consultar(id);

        if (m.idMovimientos_stock != 0) {
            System.out.println("\n--- DATOS ENCONTRADOS ---");
            System.out.println("ID: " + m.idMovimientos_stock);
            System.out.println("Fecha: " + m.fecha_movimiento);
            System.out.println("Cantidad: " + m.cantidad);
            System.out.println("Motivo: " + m.motivo);
            System.out.println("ID Producto: " + m.productos_idProductos);
        } else {
            System.out.println("No se encontró el movimiento de stock.");
        }

        sc.close();
    }
}
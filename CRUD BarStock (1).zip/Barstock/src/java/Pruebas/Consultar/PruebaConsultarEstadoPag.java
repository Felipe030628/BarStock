package Pruebas.Consultar;

import Controlador.EstadosPagDAO;
import modelo.EstadosPag;

public class PruebaConsultarEstadoPag {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        EstadosPagDAO dao = new EstadosPagDAO();

        // 2. Definir el ID que quieres buscar (asegúrate de que exista en tu DB)
        int idABuscar = 1; 

        System.out.println("Buscando estado de pago con ID: " + idABuscar + "...");

        // 3. Llamar al método consultar
        EstadosPag ep = dao.consultar(idABuscar);

        // 4. Mostrar el resultado
        // Verificamos si trajo datos (si el ID no existe, los campos serán nulos o 0)
        if (ep.descripcion_EstadoPago != null) {
            System.out.println("--- Registro Encontrado ---");
            System.out.println("ID: " + ep.idEstados_Pag);
            System.out.println("Descripción: " + ep.descripcion_EstadoPago);
        } else {
            System.out.println("No se encontró ningún registro con el ID: " + idABuscar);
        }
    }
}
package Pruebas.Consultar;

import Controlador.ProductosDAO;
import java.util.Scanner;
import modelo.Productos;

public class PruebaConsultarProductos {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ProductosDAO dao = new ProductosDAO();

        System.out.println("=== CONSULTAR PRODUCTO ===");
        System.out.print("Ingrese el ID del Producto: ");
        int id = sc.nextInt();

        Productos p = dao.consultar(id);

        if (p.idProductos != 0) {
            System.out.println("\n--- DATOS ENCONTRADOS ---");
            System.out.println("ID: " + p.idProductos);
            System.out.println("Número Producto: " + p.num_productos);
            System.out.println("Descripción: " + p.descripcion);
            System.out.println("Precio: " + p.precio);
            System.out.println("Stock: " + p.stock);
            System.out.println("Fecha Vencimiento: " + p.fecha_vencimiento);
            System.out.println("ID Categoría: " + p.categorias_idCategorias);
        } else {
            System.out.println("No se encontró el producto.");
        }

        sc.close();
    }
}
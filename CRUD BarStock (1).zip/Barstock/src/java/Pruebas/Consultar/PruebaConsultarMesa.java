package Pruebas.Consultar;

import Controlador.MesaDAO;
import modelo.Mesa;

public class PruebaConsultarMesa {
    public static void main(String[] args) {
        // 1. Instanciar el DAO
        MesaDAO dao = new MesaDAO();

        // 2. Llamar al método consultar con un ID que ya exista en tu base de datos
        int idABuscar = 1; 
        Mesa mesaEncontrada = dao.consultar(idABuscar);

        // 3. Mostrar los resultados
        if (mesaEncontrada != null && mesaEncontrada.num_mesa != null) {
            System.out.println("--- Mesa Encontrada ---");
            System.out.println("ID: " + mesaEncontrada.idMesa);
            System.out.println("Código: " + mesaEncontrada.cod_mesa);
            System.out.println("Número de Mesa: " + mesaEncontrada.num_mesa);
        } else {
            System.out.println("No se encontró ninguna mesa con el ID: " + idABuscar);
        }
    }
}
package Pruebas.Consultar;

import Controlador.MetodosPagoDAO;
import java.util.Scanner;
import modelo.MetodosPago;

public class PruebaConsultarMetodosPago {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MetodosPagoDAO dao = new MetodosPagoDAO();

        System.out.println("=== CONSULTAR METODO DE PAGO ===");
        System.out.print("Ingrese el ID del Metodo de Pago: ");
        int id = sc.nextInt();

        MetodosPago m = dao.consultar(id);

        if (m.idMetodos_Pago != 0) {
            System.out.println("\n--- DATOS ENCONTRADOS ---");
            System.out.println("ID: " + m.idMetodos_Pago);
            System.out.println("Descripción: " + m.descripcion_Metodo);
        } else {
            System.out.println("No se encontró el método de pago.");
        }

        sc.close();
    }
}
package Pruebas.Consultar;

import Controlador.TipoDocumentosDAO;
import java.util.Scanner;
import modelo.TiposDocumentos;

public class PruebaConsultarTipoDocumentos {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        TipoDocumentosDAO dao = new TipoDocumentosDAO();

        System.out.println("=== CONSULTAR TIPO DOCUMENTO ===");
        System.out.print("Ingrese el ID del Tipo Documento: ");
        int id = sc.nextInt();

        TiposDocumentos t = dao.consultar(id);

        if (t.idTipos_documentos != 0) {
            System.out.println("\n--- DATOS ENCONTRADOS ---");
            System.out.println("ID: " + t.idTipos_documentos);
            System.out.println("Descripción: " + t.descripcion_Doc);
            System.out.println("Consecutivo: " + t.consecutivo);
            System.out.println("ID Usuario: " + t.usuarios_idUsuarios);
        } else {
            System.out.println("No se encontró el tipo de documento.");
        }

        sc.close();
    }
}
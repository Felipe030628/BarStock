package Controlador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.Mesa;

public class MesaDAO {

    private final String url = "jdbc:mysql://localhost:3307/barstock";
    private final String user = "root";
    private final String pass = "";

    // INSERTAR
    public void insertar(Mesa m) {
        String sql = "INSERT INTO mesa (idMesa, cod_mesa, num_mesa) VALUES (?, ?, ?)";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, m.idMesa);
            ps.setInt(2, m.cod_mesa);
            ps.setString(3, m.num_mesa);
            
            ps.executeUpdate();
            System.out.println("Mesa insertada correctamente");
        } catch (SQLException e) {
            System.err.println("Error al insertar mesa: " + e.getMessage());
        }
    }

    // CONSULTAR (Corregido de String a int)
    public Mesa consultar(int id) {
        Mesa m = null; // Es mejor inicializar en null para validar si se encontró algo
        String sql = "SELECT * FROM mesa WHERE idMesa = ?";
        
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    m = new Mesa();
                    m.idMesa = rs.getInt("idMesa");
                    m.cod_mesa = rs.getInt("cod_mesa");
                    m.num_mesa = rs.getString("num_mesa");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar mesa: " + e.getMessage());
        }
        return m;
    }

    // LISTAR
    public List<Mesa> listar() {
        List<Mesa> lista = new ArrayList<>();
        String sql = "SELECT * FROM mesa";

        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Mesa m = new Mesa();
                m.idMesa = rs.getInt("idMesa");
                m.cod_mesa = rs.getInt("cod_mesa");
                m.num_mesa = rs.getString("num_mesa");
                lista.add(m);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar mesas: " + e.getMessage());
        }
        return lista;
    }

    // ACTUALIZAR
    public void actualizar(Mesa m) {
        String sql = "UPDATE mesa SET cod_mesa = ?, num_mesa = ? WHERE idMesa = ?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, m.cod_mesa);
            ps.setString(2, m.num_mesa);
            ps.setInt(3, m.idMesa);

            int filasAfectadas = ps.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Mesa actualizada correctamente");
            }
        } catch (SQLException e) {
            System.err.println("Error al actualizar mesa: " + e.getMessage());
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        String sql = "DELETE FROM mesa WHERE idMesa = ?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Mesa eliminada correctamente");
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar mesa: " + e.getMessage());
        }
    }
}
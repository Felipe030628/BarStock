package Controlador;

import modelo.TiposDocumentos;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TipoDocumentosDAO {

    private final String url = "jdbc:mysql://localhost:3307/barstock";
    private final String user = "root";
    private final String pass = "";

    // INSERTAR
    public void insertar(TiposDocumentos t) {
        String sql = "INSERT INTO tipos_documentos (descripcion_Doc, consecutivo, usuarios_idUsuarios) VALUES (?, ?, ?)";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, t.descripcion_Doc);
            ps.setInt(2, t.consecutivo);
            ps.setInt(3, t.usuarios_idUsuarios);

            ps.executeUpdate();
            System.out.println("Tipo de documento insertado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR (Individual)
    public TiposDocumentos consultar(int id) {
        TiposDocumentos t = new TiposDocumentos();
        String sql = "SELECT * FROM tipos_documentos WHERE idTipos_documentos = ?";
        
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    t.idTipos_documentos = rs.getInt("idTipos_documentos");
                    t.descripcion_Doc = rs.getString("descripcion_Doc");
                    t.consecutivo = rs.getInt("consecutivo");
                    t.usuarios_idUsuarios = rs.getInt("usuarios_idUsuarios");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return t;
    }

    // LISTAR (Todos los tipos de documentos)
    public List<TiposDocumentos> listar() {
        List<TiposDocumentos> lista = new ArrayList<>();
        String sql = "SELECT * FROM tipos_documentos";

        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                TiposDocumentos t = new TiposDocumentos();
                t.idTipos_documentos = rs.getInt("idTipos_documentos");
                t.descripcion_Doc = rs.getString("descripcion_Doc");
                t.consecutivo = rs.getInt("consecutivo");
                t.usuarios_idUsuarios = rs.getInt("usuarios_idUsuarios");
                lista.add(t);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // ACTUALIZAR
    public void actualizar(TiposDocumentos t) {
        String sql = "UPDATE tipos_documentos SET descripcion_Doc=?, consecutivo=?, usuarios_idUsuarios=? WHERE idTipos_documentos=?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, t.descripcion_Doc);
            ps.setInt(2, t.consecutivo);
            ps.setInt(3, t.usuarios_idUsuarios);
            ps.setInt(4, t.idTipos_documentos);

            ps.executeUpdate();
            System.out.println("Tipo de documento actualizado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        String sql = "DELETE FROM tipos_documentos WHERE idTipos_documentos = ?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Tipo de documento eliminado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
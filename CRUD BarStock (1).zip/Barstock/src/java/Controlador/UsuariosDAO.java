package Controlador;

import modelo.Usuarios;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuariosDAO {

    private final String url = "jdbc:mysql://localhost:3307/barstock";
    private final String user = "root";
    private final String pass = "";

    // INSERTAR
    public void insertar(Usuarios u) {
        String sql = "INSERT INTO usuarios (nombre, email, tel) VALUES (?, ?, ?)";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, u.nombre);
            ps.setString(2, u.email);
            ps.setString(3, u.tel);

            ps.executeUpdate();
            System.out.println("Usuario insertado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR (Individual)
    public Usuarios consultar(int id) {
        Usuarios u = new Usuarios();
        String sql = "SELECT * FROM usuarios WHERE idUsuarios = ?";
        
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    u.idUsuarios = rs.getInt("idUsuarios");
                    u.nombre = rs.getString("nombre");
                    u.email = rs.getString("email");
                    u.tel = rs.getString("tel");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return u;
    }

    // LISTAR (Todos los usuarios)
    public List<Usuarios> listar() {
        List<Usuarios> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuarios";

        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Usuarios u = new Usuarios();
                u.idUsuarios = rs.getInt("idUsuarios");
                u.nombre = rs.getString("nombre");
                u.email = rs.getString("email");
                u.tel = rs.getString("tel");
                lista.add(u);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // ACTUALIZAR
    public void actualizar(Usuarios u) {
        String sql = "UPDATE usuarios SET nombre=?, email=?, tel=? WHERE idUsuarios=?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, u.nombre);
            ps.setString(2, u.email);
            ps.setString(3, u.tel);
            ps.setInt(4, u.idUsuarios);

            ps.executeUpdate();
            System.out.println("Usuario actualizado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        String sql = "DELETE FROM usuarios WHERE idUsuarios = ?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Usuario eliminado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
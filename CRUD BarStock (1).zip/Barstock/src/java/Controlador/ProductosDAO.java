package Controlador;

import modelo.Productos;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductosDAO {

    private String url = "jdbc:mysql://localhost:3307/barstock";
    private String user = "root";
    private String pass = "";

    // INSERTAR
    public void insertar(Productos p) {
        String sql = "INSERT INTO productos (num_productos, descripcion, precio, stock, fecha_vencimiento, categorias_idCategorias) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.num_productos);
            ps.setString(2, p.descripcion);
            ps.setDouble(3, p.precio);
            ps.setInt(4, p.stock);
            ps.setDate(5, new java.sql.Date(p.fecha_vencimiento.getTime()));
            ps.setInt(6, p.categorias_idCategorias);

            ps.executeUpdate();
            System.out.println("Producto insertado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR (Individual)
    public Productos consultar(int id) {
        Productos p = new Productos();
        String sql = "SELECT * FROM productos WHERE idProductos = ?";
        
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    p.idProductos = rs.getInt("idProductos");
                    p.num_productos = rs.getString("num_productos");
                    p.descripcion = rs.getString("descripcion");
                    p.precio = rs.getDouble("precio");
                    p.stock = rs.getInt("stock");
                    p.fecha_vencimiento = rs.getDate("fecha_vencimiento");
                    p.categorias_idCategorias = rs.getInt("categorias_idCategorias");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return p;
    }

    // LISTAR (Todos los productos)
    public List<Productos> listar() {
        List<Productos> lista = new ArrayList<>();
        String sql = "SELECT * FROM productos";

        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Productos p = new Productos();
                p.idProductos = rs.getInt("idProductos");
                p.num_productos = rs.getString("num_productos");
                p.descripcion = rs.getString("descripcion");
                p.precio = rs.getDouble("precio");
                p.stock = rs.getInt("stock");
                p.fecha_vencimiento = rs.getDate("fecha_vencimiento");
                p.categorias_idCategorias = rs.getInt("categorias_idCategorias");
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // ACTUALIZAR
    public void actualizar(Productos p) {
        String sql = "UPDATE productos SET num_productos=?, descripcion=?, precio=?, stock=?, fecha_vencimiento=?, categorias_idCategorias=? WHERE idProductos=?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.num_productos);
            ps.setString(2, p.descripcion);
            ps.setDouble(3, p.precio);
            ps.setInt(4, p.stock);
            ps.setDate(5, new java.sql.Date(p.fecha_vencimiento.getTime()));
            ps.setInt(6, p.categorias_idCategorias);
            ps.setInt(7, p.idProductos);

            ps.executeUpdate();
            System.out.println("Producto actualizado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        String sql = "DELETE FROM productos WHERE idProductos = ?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Producto eliminado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
package Controlador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.Categorias;

public class CategoriaDAO {

    private String url = "jdbc:mysql://localhost:3307/barstock";
    private String user = "root";
    private String pass = "";

    // INSERTAR
    public void insertar(Categorias c) {
        String sql = "INSERT INTO categorias (nom_categoria, descripcion) VALUES (?, ?)";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, c.nom_categoria);
            ps.setString(2, c.descripcion);
            
            ps.executeUpdate();
            System.out.println("Categoria insertada correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR (Individual)
    public Categorias consultar(int id) {
        Categorias c = new Categorias();
        String sql = "SELECT * FROM categorias WHERE idCategorias = ?";
        
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                c.idCategorias = rs.getInt("idCategorias");
                c.nom_categoria = rs.getString("nom_categoria");
                c.descripcion = rs.getString("descripcion");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return c;
    }

    // LISTAR (Todos los registros)
    public List<Categorias> listar() {
        List<Categorias> lista = new ArrayList<>();
        String sql = "SELECT * FROM categorias";

        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Categorias c = new Categorias();
                c.idCategorias = rs.getInt("idCategorias");
                c.nom_categoria = rs.getString("nom_categoria");
                c.descripcion = rs.getString("descripcion");
                lista.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // ACTUALIZAR
    public void actualizar(Categorias c) {
        String sql = "UPDATE categorias SET nom_categoria=?, descripcion=? WHERE idCategorias=?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, c.nom_categoria);
            ps.setString(2, c.descripcion);
            ps.setInt(3, c.idCategorias);

            ps.executeUpdate();
            System.out.println("Categoria actualizada correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        String sql = "DELETE FROM categorias WHERE idCategorias = ?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Categoria eliminada correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
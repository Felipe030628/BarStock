package Controlador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.EstadosPag;

public class EstadosPagDAO {

    private String url = "jdbc:mysql://localhost:3307/barstock";
    private String user = "root";
    private String pass = "";

    // INSERTAR
    public void insertar(EstadosPag e) {
        String sql = "INSERT INTO estados_pag (descripcion_EstadoPago) VALUES (?)";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, e.descripcion_EstadoPago);
            ps.executeUpdate();
            
            System.out.println("Estado de pago insertado correctamente");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // CONSULTAR (Individual)
    public EstadosPag consultar(int id) {
        EstadosPag e = new EstadosPag();
        String sql = "SELECT * FROM estados_pag WHERE idEstados_Pag = ?";
        
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    e.idEstados_Pag = rs.getInt("idEstados_Pag");
                    e.descripcion_EstadoPago = rs.getString("descripcion_EstadoPago");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return e;
    }

    // LISTAR (Todos los estados de pago)
    public List<EstadosPag> listar() {
        List<EstadosPag> lista = new ArrayList<>();
        String sql = "SELECT * FROM estados_pag";

        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                EstadosPag e = new EstadosPag();
                e.idEstados_Pag = rs.getInt("idEstados_Pag");
                e.descripcion_EstadoPago = rs.getString("descripcion_EstadoPago");
                lista.add(e);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return lista;
    }

    // ACTUALIZAR
    public void actualizar(EstadosPag e) {
        String sql = "UPDATE estados_pag SET descripcion_EstadoPago = ? WHERE idEstados_Pag = ?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, e.descripcion_EstadoPago);
            ps.setInt(2, e.idEstados_Pag);

            ps.executeUpdate();
            System.out.println("Estado de pago actualizado correctamente");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        String sql = "DELETE FROM estados_pag WHERE idEstados_Pag = ?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Estado de pago eliminado correctamente");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
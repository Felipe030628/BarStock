package Controlador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.MovimientosStock;

public class MovimientoStockDAO {

    private String url = "jdbc:mysql://localhost:3307/barstock";
    private String user = "root";
    private String pass = "";

    // INSERTAR
    public void insertar(MovimientosStock m) {
        String sql = "INSERT INTO movimientos_stock (fecha_movimiento, cantidad, motivo, productos_idProductos) VALUES (?, ?, ?, ?)";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, new java.sql.Date(m.fecha_movimiento.getTime()));
            ps.setInt(2, m.cantidad);
            ps.setString(3, m.motivo);
            ps.setInt(4, m.productos_idProductos);

            ps.executeUpdate();
            System.out.println("Movimiento insertado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR (Individual)
    public MovimientosStock consultar(int id) {
        MovimientosStock m = new MovimientosStock();
        String sql = "SELECT * FROM movimientos_stock WHERE idMovimientos_stock = ?";
        
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    m.idMovimientos_stock = rs.getInt("idMovimientos_stock");
                    m.fecha_movimiento = rs.getDate("fecha_movimiento");
                    m.cantidad = rs.getInt("cantidad");
                    m.motivo = rs.getString("motivo");
                    m.productos_idProductos = rs.getInt("productos_idProductos");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return m;
    }

    // LISTAR (Historial de movimientos)
    public List<MovimientosStock> listar() {
        List<MovimientosStock> lista = new ArrayList<>();
        String sql = "SELECT * FROM movimientos_stock ORDER BY fecha_movimiento DESC";

        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                MovimientosStock m = new MovimientosStock();
                m.idMovimientos_stock = rs.getInt("idMovimientos_stock");
                m.fecha_movimiento = rs.getDate("fecha_movimiento");
                m.cantidad = rs.getInt("cantidad");
                m.motivo = rs.getString("motivo");
                m.productos_idProductos = rs.getInt("productos_idProductos");
                lista.add(m);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // ACTUALIZAR
    public void actualizar(MovimientosStock m) {
        String sql = "UPDATE movimientos_stock SET fecha_movimiento=?, cantidad=?, motivo=?, productos_idProductos=? WHERE idMovimientos_stock=?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, new java.sql.Date(m.fecha_movimiento.getTime()));
            ps.setInt(2, m.cantidad);
            ps.setString(3, m.motivo);
            ps.setInt(4, m.productos_idProductos);
            ps.setInt(5, m.idMovimientos_stock);

            ps.executeUpdate();
            System.out.println("Movimiento actualizado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        String sql = "DELETE FROM movimientos_stock WHERE idMovimientos_stock = ?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Movimiento eliminado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
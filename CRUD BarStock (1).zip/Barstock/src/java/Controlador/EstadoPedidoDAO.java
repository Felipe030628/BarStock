package Controlador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.EstadoPedido;

public class EstadoPedidoDAO {

    private String url = "jdbc:mysql://localhost:3307/barstock";
    private String user = "root";
    private String pass = "";

    // INSERTAR
    public void insertar(EstadoPedido e) {
        String sql = "INSERT INTO estado_pedido (estado_pedidoCol) VALUES (?)";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, e.estado_pedidoCol);
            ps.executeUpdate();
            
            System.out.println("Estado insertado correctamente");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // CONSULTAR (Individual)
    public EstadoPedido consultar(int id) {
        EstadoPedido e = new EstadoPedido();
        String sql = "SELECT * FROM estado_pedido WHERE idEstado_Pedido = ?";
        
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    e.idEstado_Pedido = rs.getInt("idEstado_Pedido");
                    e.estado_pedidoCol = rs.getString("estado_pedidoCol");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return e;
    }

    // LISTAR (Todos los estados)
    public List<EstadoPedido> listar() {
        List<EstadoPedido> lista = new ArrayList<>();
        String sql = "SELECT * FROM estado_pedido";

        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                EstadoPedido e = new EstadoPedido();
                e.idEstado_Pedido = rs.getInt("idEstado_Pedido");
                e.estado_pedidoCol = rs.getString("estado_pedidoCol");
                lista.add(e);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return lista;
    }

    // ACTUALIZAR
    public void actualizar(EstadoPedido e) {
        String sql = "UPDATE estado_pedido SET estado_pedidoCol = ? WHERE idEstado_Pedido = ?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, e.estado_pedidoCol);
            ps.setInt(2, e.idEstado_Pedido);

            ps.executeUpdate();
            System.out.println("Estado actualizado correctamente");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        String sql = "DELETE FROM estado_pedido WHERE idEstado_Pedido = ?";
        try (Connection con = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Estado eliminado correctamente");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
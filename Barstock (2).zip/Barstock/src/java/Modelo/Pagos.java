package modelo;

public class Pagos {

    private int idPagos;
    private double monto;
    private int pedido_Cabecera_idPedido;
    private int estados_Pag_idEstados_Pag;
    private int metodos_Pago_idMetodos_Pago;

    public Pagos() {
    }

    public Pagos(int idPagos, double monto, int pedido_Cabecera_idPedido, int estados_Pag_idEstados_Pag, int metodos_Pago_idMetodos_Pago) {
        this.idPagos = idPagos;
        this.monto = monto;
        this.pedido_Cabecera_idPedido = pedido_Cabecera_idPedido;
        this.estados_Pag_idEstados_Pag = estados_Pag_idEstados_Pag;
        this.metodos_Pago_idMetodos_Pago = metodos_Pago_idMetodos_Pago;
    }

    public int getIdPagos() {
        return idPagos;
    }

    public void setIdPagos(int idPagos) {
        this.idPagos = idPagos;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public int getPedido_Cabecera_idPedido() {
        return pedido_Cabecera_idPedido;
    }

    public void setPedido_Cabecera_idPedido(int pedido_Cabecera_idPedido) {
        this.pedido_Cabecera_idPedido = pedido_Cabecera_idPedido;
    }

    public int getEstados_Pag_idEstados_Pag() {
        return estados_Pag_idEstados_Pag;
    }

    public void setEstados_Pag_idEstados_Pag(int estados_Pag_idEstados_Pag) {
        this.estados_Pag_idEstados_Pag = estados_Pag_idEstados_Pag;
    }

    public int getMetodos_Pago_idMetodos_Pago() {
        return metodos_Pago_idMetodos_Pago;
    }

    public void setMetodos_Pago_idMetodos_Pago(int metodos_Pago_idMetodos_Pago) {
        this.metodos_Pago_idMetodos_Pago = metodos_Pago_idMetodos_Pago;
    }
}

package modelo;

public class MetodosPago {

    private int idMetodos_Pago;
    private String descripcion_Metodo;

    public MetodosPago() {
    }

    public MetodosPago(int idMetodos_Pago, String descripcion_Metodo) {
        this.idMetodos_Pago = idMetodos_Pago;
        this.descripcion_Metodo = descripcion_Metodo;
    }

    public int getIdMetodos_Pago() {
        return idMetodos_Pago;
    }

    public void setIdMetodos_Pago(int idMetodos_Pago) {
        this.idMetodos_Pago = idMetodos_Pago;
    }

    public String getDescripcion_Metodo() {
        return descripcion_Metodo;
    }

    public void setDescripcion_Metodo(String descripcion_Metodo) {
        this.descripcion_Metodo = descripcion_Metodo;
    }

    public void setIdMetodo_Pago(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getIdMetodo_Pago() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

package modelo;

public class TiposDocumentos {

    private int idTipos_documentos;
    private String descripcion_Doc;
    private int consecutivo;
    private int usuarios_idUsuarios;

    public TiposDocumentos() {
    }

    public TiposDocumentos(int idTipos_documentos, String descripcion_Doc, int consecutivo, int usuarios_idUsuarios) {
        this.idTipos_documentos = idTipos_documentos;
        this.descripcion_Doc = descripcion_Doc;
        this.consecutivo = consecutivo;
        this.usuarios_idUsuarios = usuarios_idUsuarios;
    }

    public int getIdTipos_documentos() {
        return idTipos_documentos;
    }

    public void setIdTipos_documentos(int idTipos_documentos) {
        this.idTipos_documentos = idTipos_documentos;
    }

    public String getDescripcion_Doc() {
        return descripcion_Doc;
    }

    public void setDescripcion_Doc(String descripcion_Doc) {
        this.descripcion_Doc = descripcion_Doc;
    }

    public int getConsecutivo() {
        return consecutivo;
    }

    public void setConsecutivo(int consecutivo) {
        this.consecutivo = consecutivo;
    }

    public int getUsuarios_idUsuarios() {
        return usuarios_idUsuarios;
    }

    public void setUsuarios_idUsuarios(int usuarios_idUsuarios) {
        this.usuarios_idUsuarios = usuarios_idUsuarios;
    }
}

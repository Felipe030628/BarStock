package modelo;

public class SeguimientoPedido {

    private int idSeguimientoPedido;
    private String seguimientoPedidoCol;
    private int estadoPedidoId;
    private int pedidoId;

    public SeguimientoPedido() {
    }

    public SeguimientoPedido(int idSeguimientoPedido, String seguimientoPedidoCol, int estadoPedidoId, int pedidoId) {
        this.idSeguimientoPedido = idSeguimientoPedido;
        this.seguimientoPedidoCol = seguimientoPedidoCol;
        this.estadoPedidoId = estadoPedidoId;
        this.pedidoId = pedidoId;
    }

    public int getIdSeguimientoPedido() {
        return idSeguimientoPedido;
    }

    public void setIdSeguimientoPedido(int idSeguimientoPedido) {
        this.idSeguimientoPedido = idSeguimientoPedido;
    }

    public String getSeguimientoPedidoCol() {
        return seguimientoPedidoCol;
    }

    public void setSeguimientoPedidoCol(String seguimientoPedidoCol) {
        this.seguimientoPedidoCol = seguimientoPedidoCol;
    }

    public int getEstadoPedidoId() {
        return estadoPedidoId;
    }

    public void setEstadoPedidoId(int estadoPedidoId) {
        this.estadoPedidoId = estadoPedidoId;
    }

    public int getPedidoId() {
        return pedidoId;
    }

    public void setPedidoId(int pedidoId) {
        this.pedidoId = pedidoId;
    }
}


package modelo;

public class Categorias {
    private int idCategorias;
    private String nom_categoria;
    private String descripcion;

    // Constructor sin ID (AUTO_INCREMENT)
    public Categorias(String nom_categoria, String descripcion) {
        this.nom_categoria = nom_categoria;
        this.descripcion = descripcion;
    }

    public Categorias() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getIdCategorias() {
        return idCategorias;
    }

    public String getNom_categoria() {
        return nom_categoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setIdCategorias(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setNom_categoria(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setDescripcion(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

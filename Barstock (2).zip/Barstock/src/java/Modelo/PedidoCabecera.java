package modelo;

import java.sql.Timestamp;

public class PedidoCabecera {

    private int idPedido;
    private Timestamp fecha_hora;
    private int usuarios_idUsuarios;
    private String mesa_idMesa;

    public PedidoCabecera() {
    }

    public PedidoCabecera(int idPedido, Timestamp fecha_hora, int usuarios_idUsuarios, String mesa_idMesa) {
        this.idPedido = idPedido;
        this.fecha_hora = fecha_hora;
        this.usuarios_idUsuarios = usuarios_idUsuarios;
        this.mesa_idMesa = mesa_idMesa;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public Timestamp getFecha_hora() {
        return fecha_hora;
    }

    public void setFecha_hora(Timestamp fecha_hora) {
        this.fecha_hora = fecha_hora;
    }

    public int getUsuarios_idUsuarios() {
        return usuarios_idUsuarios;
    }

    public void setUsuarios_idUsuarios(int usuarios_idUsuarios) {
        this.usuarios_idUsuarios = usuarios_idUsuarios;
    }

    public String getMesa_idMesa() {
        return mesa_idMesa;
    }

    public void setMesa_idMesa(String mesa_idMesa) {
        this.mesa_idMesa = mesa_idMesa;
    }
}


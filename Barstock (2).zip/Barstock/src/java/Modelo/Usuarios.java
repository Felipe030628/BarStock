package modelo;

public class Usuarios {
    private int idUsuarios;
    private String nombre;
    private String email;
    private String tel; // ahora es String

    public Usuarios() {}

    public Usuarios(int idUsuarios, String nombre, String email, String tel) {
        this.idUsuarios = idUsuarios;
        this.nombre = nombre;
        this.email = email;
        this.tel = tel;
    }

    public int getIdUsuarios() { return idUsuarios; }
    public void setIdUsuarios(int idUsuarios) { this.idUsuarios = idUsuarios; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getTel() { return tel; }
    public void setTel(String tel) { this.tel = tel; }
}

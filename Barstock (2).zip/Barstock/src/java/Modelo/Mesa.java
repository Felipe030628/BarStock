package modelo;

public class Mesa {

    private String idMesa;
    private int cod_mesa;
    private String num_mesa;

    public Mesa() {
    }

    public Mesa(String idMesa, int cod_mesa, String num_mesa) {
        this.idMesa = idMesa;
        this.cod_mesa = cod_mesa;
        this.num_mesa = num_mesa;
    }

    public String getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(String idMesa) {
        this.idMesa = idMesa;
    }

    public int getCod_mesa() {
        return cod_mesa;
    }

    public void setCod_mesa(int cod_mesa) {
        this.cod_mesa = cod_mesa;
    }

    public String getNum_mesa() {
        return num_mesa;
    }

    public void setNum_mesa(String num_mesa) {
        this.num_mesa = num_mesa;
    }
}

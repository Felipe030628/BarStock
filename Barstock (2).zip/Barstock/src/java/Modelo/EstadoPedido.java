package modelo;

public class EstadoPedido {

    private int idEstado_Pedido;
    private String estado_pedidoCol;

    public EstadoPedido() {
    }

    public EstadoPedido(int idEstado_Pedido, String estado_pedidoCol) {
        this.idEstado_Pedido = idEstado_Pedido;
        this.estado_pedidoCol = estado_pedidoCol;
    }

    public int getIdEstado_Pedido() {
        return idEstado_Pedido;
    }

    public void setIdEstado_Pedido(int idEstado_Pedido) {
        this.idEstado_Pedido = idEstado_Pedido;
    }

    public String getEstado_pedidoCol() {
        return estado_pedidoCol;
    }

    public void setEstado_pedidoCol(String estado_pedidoCol) {
        this.estado_pedidoCol = estado_pedidoCol;
    }

    public void setIdEstado_pedido(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

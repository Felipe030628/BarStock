package modelo;

import java.util.Date;

public class MovimientosStock {

    private int idMovimientos_stock;
    private Date fecha_movimiento;
    private int cantidad;
    private String motivo;
    private int productos_idProductos;

    public MovimientosStock() {}

    public MovimientosStock(int idMovimientos_stock, Date fecha_movimiento, int cantidad, String motivo, int productos_idProductos) {
        this.idMovimientos_stock = idMovimientos_stock;
        this.fecha_movimiento = fecha_movimiento;
        this.cantidad = cantidad;
        this.motivo = motivo;
        this.productos_idProductos = productos_idProductos;
    }

    public int getIdMovimientos_stock() {
        return idMovimientos_stock;
    }

    public void setIdMovimientos_stock(int idMovimientos_stock) {
        this.idMovimientos_stock = idMovimientos_stock;
    }

    public Date getFecha_movimiento() {
        return fecha_movimiento;
    }

    public void setFecha_movimiento(Date fecha_movimiento) {
        this.fecha_movimiento = fecha_movimiento;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public int getProductos_idProductos() {
        return productos_idProductos;
    }

    public void setProductos_idProductos(int productos_idProductos) {
        this.productos_idProductos = productos_idProductos;
    }
}

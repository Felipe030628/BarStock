package modelo;

import java.util.Date;

public class Productos {

    private int idProductos;
    private String num_productos;
    private String descripcion;
    private double precio;
    private int stock;
    private Date fecha_vencimiento;
    private int categorias_idCategorias;

    public Productos() {
    }

    public Productos(int idProductos, String num_productos, String descripcion, double precio, int stock, Date fecha_vencimiento, int categorias_idCategorias) {
        this.idProductos = idProductos;
        this.num_productos = num_productos;
        this.descripcion = descripcion;
        this.precio = precio;
        this.stock = stock;
        this.fecha_vencimiento = fecha_vencimiento;
        this.categorias_idCategorias = categorias_idCategorias;
    }

    public int getIdProductos() {
        return idProductos;
    }

    public void setIdProductos(int idProductos) {
        this.idProductos = idProductos;
    }

    public String getNum_productos() {
        return num_productos;
    }

    public void setNum_productos(String num_productos) {
        this.num_productos = num_productos;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Date getFecha_vencimiento() {
        return fecha_vencimiento;
    }

    public void setFecha_vencimiento(Date fecha_vencimiento) {
        this.fecha_vencimiento = fecha_vencimiento;
    }

    public int getCategorias_idCategorias() {
        return categorias_idCategorias;
    }

    public void setCategorias_idCategorias(int categorias_idCategorias) {
        this.categorias_idCategorias = categorias_idCategorias;
    }
}

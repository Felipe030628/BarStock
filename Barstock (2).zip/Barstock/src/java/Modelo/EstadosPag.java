package modelo;

public class EstadosPag {

    private int idEstados_Pag;
    private String descripcion_EstadoPago;

    public EstadosPag() {
    }

    public EstadosPag(int idEstados_Pag, String descripcion_EstadoPago) {
        this.idEstados_Pag = idEstados_Pag;
        this.descripcion_EstadoPago = descripcion_EstadoPago;
    }

    public int getIdEstados_Pag() {
        return idEstados_Pag;
    }

    public void setIdEstados_Pag(int idEstados_Pag) {
        this.idEstados_Pag = idEstados_Pag;
    }

    public String getDescripcion_EstadoPago() {
        return descripcion_EstadoPago;
    }

    public void setDescripcion_EstadoPago(String descripcion_EstadoPago) {
        this.descripcion_EstadoPago = descripcion_EstadoPago;
    }
}

package controlador;

import modelo.SeguimientoPedido;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SeguimientoPedidoDAO {

    private Connection con;

    public SeguimientoPedidoDAO() {
        con = Conexion.getConexion();
        if (con == null) {
            System.out.println("❌ ERROR: La conexión es NULL. No se puede ejecutar el DAO.");
        }
    }

    public boolean insertar(SeguimientoPedido sp) {

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return false;
        }

        String sql = "INSERT INTO seguimientopedido "
                   + "(idSeguimientoPedido, seguimientoPedidoCol, estado_Pedido_idEstado_Pedido, pedido_idPedido) "
                   + "VALUES (?, ?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, sp.getIdSeguimientoPedido());
            ps.setString(2, sp.getSeguimientoPedidoCol());
            ps.setInt(3, sp.getEstadoPedidoId());
            ps.setInt(4, sp.getPedidoId());

            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            System.out.println("❌ Error al insertar SeguimientoPedido: " + e.getMessage());
            return false;
        }
    }

   
    public List<SeguimientoPedido> consultar() {

        List<SeguimientoPedido> lista = new ArrayList<>();

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return lista;
        }

        String sql = "SELECT idSeguimientoPedido, seguimientoPedidoCol, estado_Pedido_idEstado_Pedido, pedido_idPedido "
                   + "FROM seguimientopedido";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                SeguimientoPedido sp = new SeguimientoPedido();

                sp.setIdSeguimientoPedido(rs.getInt("idSeguimientoPedido"));
                sp.setSeguimientoPedidoCol(rs.getString("seguimientoPedidoCol"));
                sp.setEstadoPedidoId(rs.getInt("estado_Pedido_idEstado_Pedido"));
                sp.setPedidoId(rs.getInt("pedido_idPedido"));

                lista.add(sp);
            }

        } catch (Exception e) {
            System.out.println("❌ Error al consultar SeguimientoPedido: " + e.getMessage());
        }

        return lista;
    }
}

package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import modelo.EstadosPag;

public class EstadosPagDAO {

    private Connection con;

    public EstadosPagDAO() {
        con = Conexion.getConexion();
    }

  
    public boolean insertar(EstadosPag ep) {

        String sql = "INSERT INTO estados_pag (descripcion_EstadoPago) VALUES (?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, ep.getDescripcion_EstadoPago());
            ps.executeUpdate();

            return true;

        } catch (Exception e) {
            System.out.println("❌ Error al insertar Estados_pag: " + e.getMessage());
            return false;
        }
    }

  
    public List<EstadosPag> consultar() {

        String sql = "SELECT idEstados_Pag, descripcion_EstadoPago FROM estados_pag";
        List<EstadosPag> lista = new ArrayList<>();

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                EstadosPag ep = new EstadosPag();

                ep.setIdEstados_Pag(rs.getInt("idEstados_Pag"));
                ep.setDescripcion_EstadoPago(rs.getString("descripcion_EstadoPago"));

                lista.add(ep);
            }

        } catch (Exception e) {
            System.out.println("❌ Error al consultar Estados_pag: " + e.getMessage());
        }

        return lista;
    }
}


package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import modelo.EstadoPedido;

public class EstadoPedidoDAO {

    private Connection con;

    public EstadoPedidoDAO() {
        con = Conexion.getConexion();

        if (con == null) {
            System.out.println("❌ ERROR: La conexión es NULL. No se puede ejecutar el DAO.");
        }
    }

    // ---------------------------------------------------
    // INSERTAR ESTADO
    // ---------------------------------------------------
    public boolean insertar(EstadoPedido ep) {
        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return false;
        }

        String sql = "INSERT INTO estado_pedido (estado_pedidoCol) VALUES (?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, ep.getEstado_pedidoCol());
            ps.executeUpdate();

            return true;

        } catch (Exception e) {
            System.out.println("❌ Error al insertar estado_pedido: " + e.getMessage());
            return false;
        }
    }

    // ---------------------------------------------------
    // LISTAR TODOS LOS ESTADOS
    // ---------------------------------------------------
    public List<EstadoPedido> listar() {
        List<EstadoPedido> lista = new ArrayList<>();

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return lista;
        }

        String sql = "SELECT idEstado_pedido, estado_pedidoCol FROM estado_pedido";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                EstadoPedido ep = new EstadoPedido();
                ep.setIdEstado_pedido(rs.getInt("idEstado_pedido"));
                ep.setEstado_pedidoCol(rs.getString("estado_pedidoCol"));
                lista.add(ep);
            }

        } catch (Exception e) {
            System.out.println("❌ Error al consultar estado_pedido: " + e.getMessage());
        }

        return lista;
    }


    public EstadoPedido buscarPorId(int id) {

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return null;
        }

        String sql = "SELECT idEstado_pedido, estado_pedidoCol FROM estado_pedido WHERE idEstado_pedido = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                EstadoPedido ep = new EstadoPedido();
                ep.setIdEstado_pedido(rs.getInt("idEstado_pedido"));
                ep.setEstado_pedidoCol(rs.getString("estado_pedidoCol"));
                return ep;
            }

        } catch (Exception e) {
            System.out.println("❌ Error al buscar estado por ID: " + e.getMessage());
        }

        return null;
    }
}

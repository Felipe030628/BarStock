package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import modelo.Categorias;

public class CategoriaDAO {

    private Connection con;

    public CategoriaDAO() {
        con = Conexion.getConexion();

        if (con == null) {
            System.out.println("❌ ERROR: La conexión es NULL. No se puede ejecutar el DAO.");
        }
    }

  
    public boolean insertar(Categorias c) {
        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return false;
        }

        String sql = "INSERT INTO Categorias(idCategorias, nom_categoria, descripcion) VALUES (?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, c.getIdCategorias());
            ps.setString(2, c.getNom_categoria());
            ps.setString(3, c.getDescripcion());
            ps.executeUpdate();

            return true;

        } catch (Exception e) {
            System.out.println("❌ Error al insertar categoría: " + e.getMessage());
            return false;
        }
    }

    
    public List<Categorias> listar() {
        List<Categorias> lista = new ArrayList<>();

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return lista;
        }

        String sql = "SELECT idCategorias, nom_categoria, descripcion FROM Categorias";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Categorias c = new Categorias();
                c.setIdCategorias(rs.getInt("idCategorias"));
                c.setNom_categoria(rs.getString("nom_categoria"));
                c.setDescripcion(rs.getString("descripcion"));

                lista.add(c);
            }

        } catch (Exception e) {
            System.out.println("❌ Error al consultar categorías: " + e.getMessage());
        }

        return lista;
    }

   
    public Categorias buscarPorId(int id) {

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return null;
        }

        String sql = "SELECT idCategorias, nom_categoria, descripcion FROM Categorias WHERE idCategorias = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Categorias c = new Categorias();
                c.setIdCategorias(rs.getInt("idCategorias"));
                c.setNom_categoria(rs.getString("nom_categoria"));
                c.setDescripcion(rs.getString("descripcion"));
                return c;
            }

        } catch (Exception e) {
            System.out.println("❌ Error al buscar categoría por ID: " + e.getMessage());
        }

        return null;
    }
}

package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import modelo.MetodosPago;

public class MetodosPagoDAO {

    private Connection con;

    public MetodosPagoDAO() {
        con = Conexion.getConexion();

        if (con == null) {
            System.out.println("❌ ERROR: La conexión es NULL. No se puede ejecutar el DAO.");
        }
    }

    // ---------------------------------------------------
    // INSERTAR MÉTODO DE PAGO
    // ---------------------------------------------------
    public boolean insertar(MetodosPago mp) {

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return false;
        }

        String sql = "INSERT INTO metodos_pago (descripcion_Metodo) VALUES (?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, mp.getDescripcion_Metodo());
            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            System.out.println("❌ Error al insertar Metodo_pago: " + e.getMessage());
            return false;
        }
    }


    public List<MetodosPago> listar() {
        List<MetodosPago> lista = new ArrayList<>();

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return lista;
        }

        String sql = "SELECT idMetodo_Pago, descripcion_Metodo FROM metodos_pago";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                MetodosPago mp = new MetodosPago();
                mp.setIdMetodo_Pago(rs.getInt("idMetodo_Pago"));
                mp.setDescripcion_Metodo(rs.getString("descripcion_Metodo"));

                lista.add(mp);
            }

        } catch (Exception e) {
            System.out.println("❌ Error al consultar metodos_pago: " + e.getMessage());
        }

        return lista;
    }

  
    public MetodosPago buscarPorId(int id) {

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return null;
        }

        String sql = "SELECT idMetodo_Pago, descripcion_Metodo FROM metodos_pago WHERE idMetodo_Pago = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                MetodosPago mp = new MetodosPago();
                mp.setIdMetodo_Pago(rs.getInt("idMetodo_Pago"));
                mp.setDescripcion_Metodo(rs.getString("descripcion_Metodo"));
                return mp;
            }

        } catch (Exception e) {
            System.out.println("❌ Error al buscar metodo_pago por ID: " + e.getMessage());
        }

        return null;
    }
}

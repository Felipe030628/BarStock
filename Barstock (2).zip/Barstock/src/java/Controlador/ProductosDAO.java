package controlador;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Productos;

public class ProductosDAO {

    private Connection con;

    public ProductosDAO() {
        con = Conexion.getConexion();

        if (con == null) {
            System.out.println("❌ ERROR: La conexión es NULL. No se puede ejecutar el DAO.");
        }
    }

   
    public boolean insertar(Productos producto) {

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return false;
        }

        String sql = "INSERT INTO Productos (num_productos, descripcion, precio, Stock, fecha_vencimiento, categorias_idCategorias) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, producto.getNum_productos());
            ps.setString(2, producto.getDescripcion());
            ps.setDouble(3, producto.getPrecio());
            ps.setInt(4, producto.getStock());
            ps.setDate(5, new Date(producto.getFecha_vencimiento().getTime()));
            ps.setInt(6, producto.getCategorias_idCategorias());

            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("❌ Error al insertar Producto: " + e.getMessage());
            return false;
        }
    }

  
    public List<Productos> listar() {

        List<Productos> lista = new ArrayList<>();

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return lista;
        }

        String sql = "SELECT * FROM Productos";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Productos p = new Productos();

                p.setNum_productos(rs.getString("num_productos"));
                p.setDescripcion(rs.getString("descripcion"));
                p.setPrecio(rs.getDouble("precio"));
                p.setStock(rs.getInt("Stock"));
                p.setFecha_vencimiento(rs.getDate("fecha_vencimiento"));
                p.setCategorias_idCategorias(rs.getInt("categorias_idCategorias"));

                lista.add(p);
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al consultar productos: " + e.getMessage());
        }

        return lista;
    }

    
    public Productos buscarPorId(String id) {

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return null;
        }

        String sql = "SELECT * FROM Productos WHERE num_productos = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                
                Productos p = new Productos();

                p.setNum_productos(rs.getString("num_productos"));
                p.setDescripcion(rs.getString("descripcion"));
                p.setPrecio(rs.getDouble("precio"));
                p.setStock(rs.getInt("Stock"));
                p.setFecha_vencimiento(rs.getDate("fecha_vencimiento"));
                p.setCategorias_idCategorias(rs.getInt("categorias_idCategorias"));

                return p;
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al buscar producto por ID: " + e.getMessage());
        }

        return null;
    }
}

package controlador;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.MovimientosStock;

public class MovimientoStockDAO {

    private Connection con;

    public MovimientoStockDAO() {
        con = Conexion.getConexion();
    }

    // INSERTAR
    public boolean insertar(MovimientosStock mov) {
        String sql = "INSERT INTO Movimientos_stock (fecha_movimiento, cantidad, motivo, productos_idProductos) "
                   + "VALUES (?, ?, ?, ?)";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setDate(1, new Date(mov.getFecha_movimiento().getTime()));
            ps.setInt(2, mov.getCantidad());
            ps.setString(3, mov.getMotivo());
            ps.setInt(4, mov.getProductos_idProductos());

            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("❌ Error al insertar Movimiento: " + e.getMessage());
            return false;
        }
    }

    // CONSULTAR TODOS
    public ArrayList<MovimientosStock> consultar() {
        ArrayList<MovimientosStock> lista = new ArrayList<>();
        String sql = "SELECT * FROM Movimientos_stock";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                MovimientosStock m = new MovimientosStock();
                m.setIdMovimientos_stock(rs.getInt("idMovimientos_stock"));
                m.setFecha_movimiento(rs.getTimestamp("fecha_movimiento"));
                m.setCantidad(rs.getInt("cantidad"));
                m.setMotivo(rs.getString("motivo"));
                m.setProductos_idProductos(rs.getInt("productos_idProductos"));

                lista.add(m);
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al consultar Movimientos: " + e.getMessage());
        }

        return lista;
    }
}

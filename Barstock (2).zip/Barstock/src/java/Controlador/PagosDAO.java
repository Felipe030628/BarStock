package controlador;

import modelo.Pagos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PagosDAO {

    private Connection con;

    public PagosDAO() {
        con = Conexion.getConexion();

        if (con == null) {
            System.out.println("❌ ERROR: La conexión es NULL. No se puede ejecutar el DAO.");
        }
    }

 
    public boolean insertar(Pagos pago) {

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return false;
        }

        String sql = "INSERT INTO pagos (idPagos, monto, pedido_Cabecera_idPedido, estados_Pag_idEstados_Pag, metodos_Pago_idMetodos_Pago) "
                   + "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, pago.getIdPagos());
            ps.setDouble(2, pago.getMonto());
            ps.setInt(3, pago.getPedido_Cabecera_idPedido());
            ps.setInt(4, pago.getEstados_Pag_idEstados_Pag());
            ps.setInt(5, pago.getMetodos_Pago_idMetodos_Pago());

            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            System.out.println("❌ Error al insertar pago: " + e.getMessage());
            return false;
        }
    }

   
    public List<Pagos> listar() {
        List<Pagos> lista = new ArrayList<>();

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return lista;
        }

        String sql = "SELECT idPagos, monto, pedido_Cabecera_idPedido, estados_Pag_idEstados_Pag, metodos_Pago_idMetodos_Pago FROM pagos";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Pagos pago = new Pagos();

                pago.setIdPagos(rs.getInt("idPagos"));
                pago.setMonto(rs.getDouble("monto"));
                pago.setPedido_Cabecera_idPedido(rs.getInt("pedido_Cabecera_idPedido"));
                pago.setEstados_Pag_idEstados_Pag(rs.getInt("estados_Pag_idEstados_Pag"));
                pago.setMetodos_Pago_idMetodos_Pago(rs.getInt("metodos_Pago_idMetodos_Pago"));

                lista.add(pago);
            }

        } catch (Exception e) {
            System.out.println("❌ Error al consultar pagos: " + e.getMessage());
        }

        return lista;
    }


    public Pagos buscarPorId(int id) {

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return null;
        }

        String sql = "SELECT idPagos, monto, pedido_Cabecera_idPedido, estados_Pag_idEstados_Pag, metodos_Pago_idMetodos_Pago "
                   + "FROM pagos WHERE idPagos = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Pagos pago = new Pagos();

                pago.setIdPagos(rs.getInt("idPagos"));
                pago.setMonto(rs.getDouble("monto"));
                pago.setPedido_Cabecera_idPedido(rs.getInt("pedido_Cabecera_idPedido"));
                pago.setEstados_Pag_idEstados_Pag(rs.getInt("estados_Pag_idEstados_Pag"));
                pago.setMetodos_Pago_idMetodos_Pago(rs.getInt("metodos_Pago_idMetodos_Pago"));

                return pago;
            }

        } catch (Exception e) {
            System.out.println("❌ Error al buscar pago por ID: " + e.getMessage());
        }

        return null;
    }
}

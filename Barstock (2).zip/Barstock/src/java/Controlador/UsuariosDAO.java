package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Usuarios;

public class UsuariosDAO {

    private Connection con;

    public UsuariosDAO() {
        con = Conexion.getConexion();
    }

  
    public boolean insertar(Usuarios u) {
        String sql = "INSERT INTO Usuarios (idUsuarios, nombre, email, tel) VALUES (?, ?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, u.getIdUsuarios());
            ps.setString(2, u.getNombre());
            ps.setString(3, u.getEmail());
            ps.setString(4, u.getTel());

            int filas = ps.executeUpdate();
            return filas > 0;

        } catch (SQLException e) {
            System.out.println("❌ Error al insertar Usuario: " + e.getMessage());
            return false;
        }
    }

 
    public List<Usuarios> consultar() {

        String sql = "SELECT idUsuarios, nombre, email, tel FROM Usuarios";
        List<Usuarios> lista = new ArrayList<>();

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Usuarios u = new Usuarios();

                u.setIdUsuarios(rs.getInt("idUsuarios"));
                u.setNombre(rs.getString("nombre"));
                u.setEmail(rs.getString("email"));
                u.setTel(rs.getString("tel"));

                lista.add(u);
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al consultar Usuarios: " + e.getMessage());
        }

        return lista;
    }
}

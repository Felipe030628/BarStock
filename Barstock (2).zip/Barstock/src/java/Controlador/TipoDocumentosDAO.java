package controlador;

import modelo.TiposDocumentos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class TipoDocumentosDAO {

    private Connection con;

    public TipoDocumentosDAO() {
        con = Conexion.getConexion();
    }

    public boolean insertar(TiposDocumentos doc) {
        String sql = "INSERT INTO tipos_documentos (idTipos_documentos, descripcion_Doc, consecutivo, usuarios_idUsuarios) "
                   + "VALUES (?, ?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, doc.getIdTipos_documentos());
            ps.setString(2, doc.getDescripcion_Doc());
            ps.setInt(3, doc.getConsecutivo());
            ps.setInt(4, doc.getUsuarios_idUsuarios());

            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            System.out.println("❌ Error al insertar tipo de documento: " + e.getMessage());
            return false;
        }
    }

    public List<TiposDocumentos> consultar() {

        String sql = "SELECT idTipos_documentos, descripcion_Doc, consecutivo, usuarios_idUsuarios "
                   + "FROM tipos_documentos";

        List<TiposDocumentos> lista = new ArrayList<>();

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                TiposDocumentos doc = new TiposDocumentos();

                doc.setIdTipos_documentos(rs.getInt("idTipos_documentos"));
                doc.setDescripcion_Doc(rs.getString("descripcion_Doc"));
                doc.setConsecutivo(rs.getInt("consecutivo"));
                doc.setUsuarios_idUsuarios(rs.getInt("usuarios_idUsuarios"));

                lista.add(doc);
            }

        } catch (Exception e) {
            System.out.println("❌ Error al consultar tipos de documentos: " + e.getMessage());
        }

        return lista;
    }
}


package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import modelo.Mesa;

public class MesaDAO {

    private Connection con;

    public MesaDAO() {
        con = Conexion.getConexion();

        if (con == null) {
            System.out.println("❌ ERROR: La conexión es NULL. No se puede ejecutar el DAO.");
        }
    }

    
    public boolean insertar(Mesa m) {

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return false;
        }

        String sql = "INSERT INTO mesa (idMesa, cod_mesa, num_mesa) VALUES (?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, m.getIdMesa());
            ps.setInt(2, m.getCod_mesa());
            ps.setString(3, m.getNum_mesa());

            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            System.out.println("❌ Error al insertar Mesa: " + e.getMessage());
            return false;
        }
    }

  
    public List<Mesa> listar() {
        List<Mesa> lista = new ArrayList<>();

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return lista;
        }

        String sql = "SELECT idMesa, cod_mesa, num_mesa FROM mesa";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Mesa m = new Mesa();
                m.setIdMesa(rs.getString("idMesa"));
                m.setCod_mesa(rs.getInt("cod_mesa"));
                m.setNum_mesa(rs.getString("num_mesa"));
                lista.add(m);
            }

        } catch (Exception e) {
            System.out.println("❌ Error al consultar mesas: " + e.getMessage());
        }

        return lista;
    }

   
    public Mesa buscarPorId(String id) {

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return null;
        }

        String sql = "SELECT idMesa, cod_mesa, num_mesa FROM mesa WHERE idMesa = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Mesa m = new Mesa();
                m.setIdMesa(rs.getString("idMesa"));
                m.setCod_mesa(rs.getInt("cod_mesa"));
                m.setNum_mesa(rs.getString("num_mesa"));
                return m;
            }

        } catch (Exception e) {
            System.out.println("❌ Error al buscar mesa por ID: " + e.getMessage());
        }

        return null;
    }
}

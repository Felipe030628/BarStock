package controlador;

import modelo.PedidoCabecera;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PedidoCabeceraDAO {

    private Connection con;

    public PedidoCabeceraDAO() {
        con = Conexion.getConexion();

        if (con == null) {
            System.out.println("❌ ERROR: La conexión es NULL. No se puede ejecutar el DAO.");
        }
    }

 
    public boolean insertar(PedidoCabecera pedido) {

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return false;
        }

        String sql = "INSERT INTO pedido_cabecera (idPedido, fecha_hora, usuarios_idUsuarios, mesa_idMesa) "
                   + "VALUES (?, ?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, pedido.getIdPedido());
            ps.setTimestamp(2, pedido.getFecha_hora());
            ps.setInt(3, pedido.getUsuarios_idUsuarios());
            ps.setString(4, pedido.getMesa_idMesa());

            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            System.out.println("❌ Error al insertar pedido cabecera: " + e.getMessage());
            return false;
        }
    }

   
    public List<PedidoCabecera> listar() {
        List<PedidoCabecera> lista = new ArrayList<>();

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return lista;
        }

        String sql = "SELECT idPedido, fecha_hora, usuarios_idUsuarios, mesa_idMesa FROM pedido_cabecera";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                PedidoCabecera pc = new PedidoCabecera();

                pc.setIdPedido(rs.getInt("idPedido"));
                pc.setFecha_hora(rs.getTimestamp("fecha_hora"));
                pc.setUsuarios_idUsuarios(rs.getInt("usuarios_idUsuarios"));
                pc.setMesa_idMesa(rs.getString("mesa_idMesa"));

                lista.add(pc);
            }

        } catch (Exception e) {
            System.out.println("❌ Error al consultar pedidos cabecera: " + e.getMessage());
        }

        return lista;
    }

    
    public PedidoCabecera buscarPorId(int id) {

        if (con == null) {
            System.out.println("❌ No hay conexión. Revisa la clase Conexion.");
            return null;
        }

        String sql = "SELECT idPedido, fecha_hora, usuarios_idUsuarios, mesa_idMesa "
                   + "FROM pedido_cabecera WHERE idPedido = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                PedidoCabecera pc = new PedidoCabecera();

                pc.setIdPedido(rs.getInt("idPedido"));
                pc.setFecha_hora(rs.getTimestamp("fecha_hora"));
                pc.setUsuarios_idUsuarios(rs.getInt("usuarios_idUsuarios"));
                pc.setMesa_idMesa(rs.getString("mesa_idMesa"));

                return pc;
            }

        } catch (Exception e) {
            System.out.println("❌ Error al buscar pedido cabecera por ID: " + e.getMessage());
        }

        return null;
    }
}

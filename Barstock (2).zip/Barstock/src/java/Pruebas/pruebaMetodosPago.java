package pruebas;

import controlador.MetodosPagoDAO;
import java.util.Scanner;
import modelo.MetodosPago;

public class pruebaMetodosPago {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MetodosPagoDAO dao = new MetodosPagoDAO();

        System.out.println("===== INSERTAR MÉTODO DE PAGO =====");

        System.out.print("Ingrese la descripción del método de pago: ");
        String descripcion = sc.nextLine();

        MetodosPago mp = new MetodosPago(0, descripcion);

        boolean res = dao.insertar(mp);

        if (res) {
            System.out.println("✅ Método de pago insertado con éxito.");
        } else {
            System.out.println("❌ Error al insertar.");
        }
    }
}

package pruebas;

import controlador.Conexion;
import java.sql.Connection;

public class prueba {

    public static void main(String[] args) {

        Conexion conexion = new Conexion();
        Connection con = Conexion.getConexion();

        if (con != null) {
            System.out.println("✔ La conexión funciona correctamente.");
        } else {
            System.out.println("❌ No se pudo conectar a la base de datos.");
        }
    }
}

package Pruebas;

import controlador.EstadoPedidoDAO;
import java.util.List;
import modelo.EstadoPedido;

public class PruebaListarEstadoPedidoDAO {

    public static void main(String[] args) {

        EstadoPedidoDAO dao = new EstadoPedidoDAO();

        System.out.println("---- LISTANDO ESTADOS ----");

        List<EstadoPedido> lista = dao.listar();

        if (lista.isEmpty()) {
            System.out.println("No hay registros en la tabla estado_pedido.");
        } else {
            for (EstadoPedido ep : lista) {
                System.out.println("ID: " + ep.getIdEstado_Pedido() +
                                   " | Estado: " + ep.getEstado_pedidoCol());
            }
        }

        System.out.println("---- FIN LISTADO ----");
    }
}

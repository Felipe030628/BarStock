package pruebas;

import controlador.MetodosPagoDAO;
import java.util.List;
import modelo.MetodosPago;

public class PruebaListarMetodosPagoDAO {

    public static void main(String[] args) {

        MetodosPagoDAO dao = new MetodosPagoDAO();

        System.out.println("---- LISTANDO MÉTODOS DE PAGO ----");

        List<MetodosPago> lista = dao.listar();

        if (lista.isEmpty()) {
            System.out.println("No hay registros en la tabla metodos_pago.");
        } else {
            for (MetodosPago mp : lista) {
                System.out.println("ID: " + mp.getIdMetodo_Pago()
                        + " | Método: " + mp.getDescripcion_Metodo());
            }
        }

        System.out.println("---- FIN LISTADO ----");
    }
}

package pruebas;

import controlador.EstadoPedidoDAO;
import java.util.Scanner;
import modelo.EstadoPedido;

public class pruebaEstadoPedido {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        EstadoPedidoDAO dao = new EstadoPedidoDAO();

        System.out.println("===== INSERTAR ESTADO DE PEDIDO =====");

        System.out.print("Ingrese descripción del estado: ");
        String estado = sc.nextLine();

        EstadoPedido ep = new EstadoPedido(0, estado);

        boolean resultado = dao.insertar(ep);

        if (resultado) {
            System.out.println("✅ Estado insertado correctamente.");
        } else {
            System.out.println("❌ Error al insertar estado.");
        }
    }
}

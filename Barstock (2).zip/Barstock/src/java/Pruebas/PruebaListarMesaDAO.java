package pruebas;

import controlador.MesaDAO;
import java.util.List;
import modelo.Mesa;

public class PruebaListarMesaDAO {

    public static void main(String[] args) {

        MesaDAO dao = new MesaDAO();

        System.out.println("---- LISTANDO MESAS ----");

        List<Mesa> lista = dao.listar();

        if (lista.isEmpty()) {
            System.out.println("No hay registros en la tabla mesa.");
        } else {
            for (Mesa m : lista) {
                System.out.println("ID: " + m.getIdMesa()
                        + " | Código: " + m.getCod_mesa()
                        + " | Número de mesa: " + m.getNum_mesa());
            }
        }

        System.out.println("---- FIN LISTADO ----");
    }
}

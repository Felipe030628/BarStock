package pruebas;

import controlador.PedidoCabeceraDAO;
import java.util.List;
import modelo.PedidoCabecera;

public class PruebaListarPedidoCabeceraDAO {

    public static void main(String[] args) {

        PedidoCabeceraDAO dao = new PedidoCabeceraDAO();

        System.out.println("---- LISTADO DE PEDIDOS CABECERA ----");

        List<PedidoCabecera> lista = dao.listar();

        if (lista.isEmpty()) {
            System.out.println("No hay pedidos registrados.");
        } else {
            for (PedidoCabecera p : lista) {
                System.out.println(
                        "ID: " + p.getIdPedido() +
                        " | Fecha-Hora: " + p.getFecha_hora() +
                        " | Usuario ID: " + p.getUsuarios_idUsuarios() +
                        " | Mesa ID: " + p.getMesa_idMesa()
                );
            }
        }

        System.out.println("---- FIN LISTADO ----");
    }
}

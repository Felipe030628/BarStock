package pruebas;

import controlador.PagosDAO;
import modelo.Pagos;
import java.util.Scanner;

public class PruebasPagos {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PagosDAO dao = new PagosDAO();

        System.out.println("===== INSERTAR PAGO =====");

        System.out.print("ID Pago: ");
        int id = sc.nextInt();

        System.out.print("Monto: ");
        double monto = sc.nextDouble();

        System.out.print("ID Pedido (FK): ");
        int idPedido = sc.nextInt();

        System.out.print("ID Estado Pago (FK): ");
        int idEstado = sc.nextInt();

        System.out.print("ID Método Pago (FK): ");
        int idMetodo = sc.nextInt();

        Pagos pago = new Pagos(id, monto, idPedido, idEstado, idMetodo);

        boolean ok = dao.insertar(pago);

        if (ok) {
            System.out.println("✅ Pago insertado correctamente.");
        } else {
            System.out.println("❌ Error al insertar.");
        }
    }
}

package pruebas;

import controlador.UsuariosDAO;
import java.util.Scanner;
import modelo.Usuarios;

public class pruebaUsuarios {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        UsuariosDAO dao = new UsuariosDAO();

        System.out.println("===== INSERTAR NUEVO USUARIO =====");

        System.out.print("ID Usuario: ");
        int id = Integer.parseInt(sc.nextLine());

        System.out.print("Nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();

        System.out.print("Teléfono: ");
        String tel = sc.nextLine(); // ahora se lee como String

        Usuarios u = new Usuarios(id, nombre, email, tel);

        boolean resultado = dao.insertar(u);

        if (resultado) {
            System.out.println("✅ Usuario insertado con éxito.");
        } else {
            System.out.println("❌ Error al insertar.");
        }

        sc.close();
    }
}

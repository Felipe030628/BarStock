package pruebas;

import controlador.SeguimientoPedidoDAO;
import java.util.List;
import modelo.SeguimientoPedido;

public class PruebaListarSeguimientoPedidoDAO {

    public static void main(String[] args) {

        SeguimientoPedidoDAO dao = new SeguimientoPedidoDAO();

        System.out.println("---- LISTA DE SEGUIMIENTO DE PEDIDOS ----");

        List<SeguimientoPedido> lista = dao.consultar();

        if (lista.isEmpty()) {
            System.out.println("No hay registros de seguimiento de pedidos.");
        } else {
            for (SeguimientoPedido sp : lista) {
                System.out.println(
                    "ID: " + sp.getIdSeguimientoPedido() +
                    " | Seguimiento: " + sp.getSeguimientoPedidoCol() +
                    " | Estado ID: " + sp.getEstadoPedidoId() +
                    " | Pedido ID: " + sp.getPedidoId()
                );
            }
        }

        System.out.println("---- FIN DE LA CONSULTA ----");
    }
}

package pruebas;

import controlador.TipoDocumentosDAO;
import modelo.TiposDocumentos;
import java.util.Scanner;

public class PruebaTipoDocumentos {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        TipoDocumentosDAO dao = new TipoDocumentosDAO();

        System.out.println("===== INSERTAR TIPO DE DOCUMENTO =====");

        System.out.print("ID Tipo de Documento: ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("Descripción: ");
        String desc = sc.nextLine();

        System.out.print("Consecutivo: ");
        int consecutivo = sc.nextInt();

        System.out.print("ID Usuario (FK): ");
        int idUsuario = sc.nextInt();

        TiposDocumentos doc = new TiposDocumentos(id, desc, consecutivo, idUsuario);

        boolean ok = dao.insertar(doc);

        if (ok) {
            System.out.println("✅ Tipo de documento insertado correctamente.");
        } else {
            System.out.println("❌ Error al insertar.");
        }
    }
}

package pruebas;

import controlador.CategoriaDAO;
import modelo.Categorias;
import java.util.List;

public class PruebaListarCategorias {

    public static void main(String[] args) {

        CategoriaDAO dao = new CategoriaDAO();

        System.out.println("=== PRUEBA DEL MÉTODO LISTAR() ===");

        List<Categorias> lista = dao.listar();

        if (lista.isEmpty()) {
            System.out.println("⚠️ La lista está vacía o no se pudo conectar a la base.");
        } else {
            for (Categorias c : lista) {
                System.out.println("---------------------------");
                System.out.println("ID: " + c.getIdCategorias());
                System.out.println("Nombre: " + c.getNom_categoria());
                System.out.println("Descripción: " + c.getDescripcion());
            }
        }
    }
}

package pruebas;

import controlador.PagosDAO;
import java.util.List;
import modelo.Pagos;

public class PruebaListarPagosDAO {

    public static void main(String[] args) {

        PagosDAO dao = new PagosDAO();

        System.out.println("---- LISTADO DE PAGOS ----");

        List<Pagos> lista = dao.listar();

        if (lista.isEmpty()) {
            System.out.println("No hay pagos registrados.");
        } else {
            for (Pagos p : lista) {
                System.out.println(
                        "ID: " + p.getIdPagos() +
                        " | Monto: " + p.getMonto() +
                        " | Pedido: " + p.getPedido_Cabecera_idPedido() +
                        " | Estado Pago: " + p.getEstados_Pag_idEstados_Pag() +
                        " | Método Pago: " + p.getMetodos_Pago_idMetodos_Pago()
                );
            }
        }

        System.out.println("---- FIN LISTADO ----");
    }
}

package pruebas;

import controlador.TipoDocumentosDAO;
import modelo.TiposDocumentos;

import java.util.List;

public class PruebaListarTipoDocumentos {

    public static void main(String[] args) {

        TipoDocumentosDAO dao = new TipoDocumentosDAO();

        System.out.println("========= INSERTAR =========");

        TiposDocumentos td = new TiposDocumentos();
        td.setIdTipos_documentos(1);
        td.setDescripcion_Doc("Cédula de ciudadanía");
        td.setConsecutivo(1001);
        td.setUsuarios_idUsuarios(3);

        if (dao.insertar(td)) {
            System.out.println("✔ Tipo de documento insertado correctamente");
        } else {
            System.out.println("❌ Error al insertar");
        }

        System.out.println("\n========= CONSULTAR =========");

        List<TiposDocumentos> lista = dao.consultar();

        for (TiposDocumentos t : lista) {
            System.out.println("--------------------------------");
            System.out.println("ID: " + t.getIdTipos_documentos());
            System.out.println("Descripción: " + t.getDescripcion_Doc());
            System.out.println("Consecutivo: " + t.getConsecutivo());
            System.out.println("Usuario ID: " + t.getUsuarios_idUsuarios());
        }
    }
}

package pruebas;

import controlador.ProductosDAO;
import java.sql.Date;
import java.util.Scanner;
import modelo.Productos;

public class pruebaProductos {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ProductosDAO dao = new ProductosDAO();

        System.out.println("===== INSERTAR PRODUCTO =====");

        System.out.print("Número del producto: ");
        String num = sc.nextLine();

        System.out.print("Descripción: ");
        String desc = sc.nextLine();

        System.out.print("Precio: ");
        double precio = sc.nextDouble();

        System.out.print("Stock: ");
        int stock = sc.nextInt();

        sc.nextLine();
        System.out.print("Fecha de vencimiento (YYYY-MM-DD): ");
        Date fecha = Date.valueOf(sc.nextLine());

        System.out.print("ID Categoría (FK): ");
        int idCat = sc.nextInt();

        Productos p = new Productos(0, num, desc, precio, stock, fecha, idCat);

        boolean res = dao.insertar(p);

        if (res) {
            System.out.println("✅ Producto insertado con éxito.");
        } else {
            System.out.println("❌ Error al insertar.");
        }
    }
}

package pruebas;

import controlador.PedidoCabeceraDAO;
import java.util.Scanner;
import modelo.PedidoCabecera;
import java.sql.Timestamp;

public class pruebaPedidoCabecera {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PedidoCabeceraDAO dao = new PedidoCabeceraDAO();

        System.out.println("===== INSERTAR PEDIDO CABECERA =====");

        System.out.print("ID Pedido: ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("ID Usuario (FK): ");
        int idUsuario = sc.nextInt();
        sc.nextLine();

        System.out.print("ID Mesa (FK): ");
        String idMesa = sc.nextLine();

        // Fecha automática actual
        Timestamp fecha = new Timestamp(System.currentTimeMillis());

        PedidoCabecera pedido = new PedidoCabecera(id, fecha, idUsuario, idMesa);

        boolean ok = dao.insertar(pedido);

        if (ok) {
            System.out.println("✅ Pedido cabecera insertado correctamente.");
        } else {
            System.out.println("❌ Error al insertar.");
        }
    }
}

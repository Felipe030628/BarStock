package pruebas;

import controlador.EstadosPagDAO;
import java.util.Scanner;
import modelo.EstadosPag;

public class pruebaEstadoPag {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        EstadosPagDAO dao = new EstadosPagDAO();

        System.out.println("===== INSERTAR ESTADO DE PAGO =====");

        System.out.print("Ingrese la descripción del estado de pago: ");
        String desc = sc.nextLine();

        EstadosPag ep = new EstadosPag(0, desc);

        boolean resultado = dao.insertar(ep);

        if (resultado) {
            System.out.println("✅ Estado de pago insertado con éxito.");
        } else {
            System.out.println("❌ Error al insertar.");
        }
    }
}

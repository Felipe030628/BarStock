package pruebas;

import controlador.ProductosDAO;
import java.util.List;
import modelo.Productos;

public class PruebaListarProductosDAO {

    public static void main(String[] args) {

        ProductosDAO dao = new ProductosDAO();

        System.out.println("---- LISTADO DE PRODUCTOS ----");

        List<Productos> lista = dao.listar();

        if (lista.isEmpty()) {
            System.out.println("No hay productos registrados.");
        } else {
            for (Productos p : lista) {
                System.out.println(
                        "Código: " + p.getNum_productos() +
                        " | Descripción: " + p.getDescripcion() +
                        " | Precio: " + p.getPrecio() +
                        " | Stock: " + p.getStock() +
                        " | Fecha venc.: " + p.getFecha_vencimiento() +
                        " | Categoría ID: " + p.getCategorias_idCategorias()
                );
            }
        }

        System.out.println("---- FIN LISTADO ----");
    }
}

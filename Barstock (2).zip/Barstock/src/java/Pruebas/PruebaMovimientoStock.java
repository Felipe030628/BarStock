package pruebas;

import controlador.MovimientoStockDAO;
import java.util.Date;
import java.util.Scanner;
import modelo.MovimientosStock;

public class PruebaMovimientoStock {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MovimientoStockDAO dao = new MovimientoStockDAO();

        System.out.println("===== INSERTAR MOVIMIENTO =====");

        System.out.print("Cantidad: ");
        int cantidad = sc.nextInt();
        sc.nextLine();  

        System.out.print("Motivo: ");
        String motivo = sc.nextLine();

        System.out.print("ID Producto (FK): ");
        int idProducto = sc.nextInt();

        MovimientosStock mov = new MovimientosStock();
        mov.setFecha_movimiento(new Date());
        mov.setCantidad(cantidad);
        mov.setMotivo(motivo);
        mov.setProductos_idProductos(idProducto);

        boolean resultado = dao.insertar(mov);

        if (resultado) {
            System.out.println("✅ Movimiento insertado correctamente.");
        } else {
            System.out.println("❌ Error al insertar.");
        }
    }
}

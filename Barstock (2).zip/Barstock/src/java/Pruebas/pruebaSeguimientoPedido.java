package pruebas;

import controlador.SeguimientoPedidoDAO;
import modelo.SeguimientoPedido;
import java.util.Scanner;

public class pruebaSeguimientoPedido {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        SeguimientoPedidoDAO dao = new SeguimientoPedidoDAO();

        System.out.println("===== INSERTAR SEGUIMIENTO PEDIDO =====");

        System.out.print("ID Seguimiento: ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("Descripción del seguimiento: ");
        String seguimiento = sc.nextLine();

        System.out.print("ID Estado Pedido (FK): ");
        int idEstado = sc.nextInt();

        System.out.print("ID Pedido (FK): ");
        int idPedido = sc.nextInt();

        SeguimientoPedido sp = new SeguimientoPedido(id, seguimiento, idEstado, idPedido);

        boolean resultado = dao.insertar(sp);

        if (resultado) {
            System.out.println("✅ Seguimiento insertado con éxito.");
        } else {
            System.out.println("❌ Error al insertar.");
        }
    }
}


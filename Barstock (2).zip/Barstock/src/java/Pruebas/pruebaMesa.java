package pruebas;

import controlador.MesaDAO;
import java.util.Scanner;
import modelo.Mesa;

public class pruebaMesa {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MesaDAO dao = new MesaDAO();

        System.out.println("===== INSERTAR MESA =====");

        System.out.print("Ingrese ID de la mesa: ");
        String id = sc.nextLine();

        System.out.print("Ingrese código de mesa: ");
        int cod = sc.nextInt();
        sc.nextLine();

        System.out.print("Ingrese número de mesa: ");
        String num = sc.nextLine();

        Mesa m = new Mesa(id, cod, num);

        boolean res = dao.insertar(m);

        if (res) {
            System.out.println("✅ Mesa insertada con éxito.");
        } else {
            System.out.println("❌ Error al insertar.");
        }
    }
}

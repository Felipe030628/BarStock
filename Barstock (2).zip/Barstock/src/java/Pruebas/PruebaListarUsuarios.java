package pruebas;

import controlador.UsuariosDAO;
import modelo.Usuarios;

import java.util.List;

public class PruebaListarUsuarios {

    public static void main(String[] args) {

        UsuariosDAO dao = new UsuariosDAO();

        System.out.println("========= INSERTAR =========");

        Usuarios u = new Usuarios();
        u.setIdUsuarios(1);
        u.setNombre("Carlos Pérez");
        u.setEmail("carlos@example.com");
        u.setTel("3124567890");

        if (dao.insertar(u)) {
            System.out.println("✔ Usuario insertado correctamente");
        } else {
            System.out.println("❌ Error al insertar usuario");
        }

        System.out.println("\n========= CONSULTAR =========");

        List<Usuarios> lista = dao.consultar();

        for (Usuarios usuario : lista) {
            System.out.println("--------------------------------");
            System.out.println("ID: " + usuario.getIdUsuarios());
            System.out.println("Nombre: " + usuario.getNombre());
            System.out.println("Email: " + usuario.getEmail());
            System.out.println("Teléfono: " + usuario.getTel());
        }
    }
}

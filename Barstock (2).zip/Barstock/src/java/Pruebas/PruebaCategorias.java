package pruebas;

import controlador.CategoriaDAO;
import java.util.Scanner;
import modelo.Categorias;

public class PruebaCategorias {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        CategoriaDAO dao = new CategoriaDAO();

        System.out.println("===== INSERTAR UNA NUEVA CATEGORIA =====");
        
        System.out.print("Ingrese nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Ingrese descripción: ");
        String descripcion = sc.nextLine();

        Categorias c = new Categorias(nombre, descripcion);

        boolean resultado = dao.insertar(c);

        if (resultado) {
            System.out.println("✅ Categoría insertada con éxito.");
        } else {
            System.out.println("❌ Error al insertar.");
        }
    }
}

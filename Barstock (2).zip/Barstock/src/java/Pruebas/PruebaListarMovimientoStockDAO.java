package pruebas;

import controlador.MovimientoStockDAO;
import java.util.ArrayList;
import modelo.MovimientosStock;

public class PruebaListarMovimientoStockDAO {

    public static void main(String[] args) {

        MovimientoStockDAO dao = new MovimientoStockDAO();

        System.out.println("---- LISTANDO MOVIMIENTOS DE STOCK ----");

        ArrayList<MovimientosStock> lista = dao.consultar();

        if (lista.isEmpty()) {
            System.out.println("No hay movimientos registrados.");
        } else {
            for (MovimientosStock m : lista) {
                System.out.println(
                        "ID: " + m.getIdMovimientos_stock()
                        + " | Fecha: " + m.getFecha_movimiento()
                        + " | Cantidad: " + m.getCantidad()
                        + " | Motivo: " + m.getMotivo()
                        + " | Producto (ID): " + m.getProductos_idProductos()
                );
            }
        }

        System.out.println("---- FIN LISTADO ----");
    }
}

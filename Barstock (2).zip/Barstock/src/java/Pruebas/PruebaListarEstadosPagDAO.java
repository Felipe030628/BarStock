package Pruebas;

import controlador.EstadosPagDAO;
import java.util.List;
import modelo.EstadosPag;

public class PruebaListarEstadosPagDAO {

    public static void main(String[] args) {

        EstadosPagDAO dao = new EstadosPagDAO();

        System.out.println("---- LISTANDO ESTADOS DE PAGO ----");

        List<EstadosPag> lista = dao.consultar();

        if (lista.isEmpty()) {
            System.out.println("No hay registros en la tabla estados_pag.");
        } else {
            for (EstadosPag ep : lista) {
                System.out.println("ID: " + ep.getIdEstados_Pag()
                        + " | Descripción: " + ep.getDescripcion_EstadoPago());
            }
        }

        System.out.println("---- FIN LISTADO ----");
    }
}
